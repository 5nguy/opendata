#!/usr/bin/env python
# -*- coding: latin1 -*-

import time,os,sys, arcgisscripting

gp = arcgisscripting.create(9.3)

def printit(instring):
    # print instring
    gp.addmessage(instring)


def printwarning(instring):
    # print instring
    gp.addwarning(instring)


def printerr(instring):
    # print instring
    gp.adderror(instring)


def splitGeocode(geocode):

    if geocode.find("+") ==0:
        operateur1 = "pos"
        geocode = geocode[geocode.find("+")+1:]

    elif geocode.find("-") ==0:
        operateur1 = 'neg'
        geocode = geocode[geocode.find("-")+1:]

    if geocode.find("+") != -1:
        valx= float(geocode.split("+")[0].replace(",","."))
        valy= float(geocode.split("+")[1].replace(",","."))

    if geocode.find("-") != -1:
        valx= float(geocode.split("-")[0].replace(",","."))
        valy= float(geocode.split("-")[1].replace(",","."))*-1

    if operateur1 =="neg":
        valx = valx*-1

    return valx,valy




def main():
    li_geoc_permis = ["GEOCODE","GEOC_MAJ","GEOC_IFM","GEOC_APM","GEOC_FMJ","GEOC_NFM","GEOC_DENLI"]



    fc = gp.GetParameterAsText(0)
    dest = gp.GetParameterAsText(1)



    # lockTest = gp.TestSchemaLock(fc)
    #
    # if lockTest:
    #     pass
    # else:
    #     printerr("Votre donn�e en entr�e est verrouill�e. Veuillez la lib�rer avant de poursuivre.")
    #     sys.exit()



    gdbpath = os.path.dirname(fc)
    ce = os.path.basename(fc)

    Xname =  "X1"
    Yname =  "Y1"


    printit("Ajout du champs temporaire X1")

    starttime = time.time()
    try:
        gp.AddField_management(fc,Xname,"DOUBLE","#","#","#","#","NULLABLE","NON_REQUIRED","#")
    except:
        pass
    printit("Ajout du champs temporaire Y1")
    try:
        gp.AddField_management(fc,Yname,"DOUBLE","#","#","#","#","NULLABLE","NON_REQUIRED","#")
    except:
        pass


    nomchamps = [champs.Name for champs in gp.ListFields(fc)]
    res = list(set(nomchamps).intersection(set(li_geoc_permis)))
    printit("S�paration du champ %s" % res[0])
    fields = res[0]+";"+Xname+";"+Yname


    try:
        import arcpy
        fields = [res[0],Xname,Yname]
        with arcpy.da.UpdateCursor(fc, fields) as up_cursor:
            for row in up_cursor:
                pxy = splitGeocode(row[0])
                row[1] = pxy[0]
                row[2] = pxy[1]
                up_cursor.updateRow(row)
            del row
        del up_cursor
    except ImportError:
        fields = res[0]+";"+Xname+";"+Yname
        rows = gp.UpdateCursor(fc, "", "", fields,"")
        row = rows.Next()
        while row:
            a=""
            exec("a =row.%s" % res[0])
            pxy = splitGeocode(a)
            row.X1 = pxy[0]
            row.Y1 = pxy[1]
            rows.UpdateRow(row)
        del row
        del rows




    printit("Cr�ation de la couche temporaire de points en Qu�bec Lambert (EPSG:32198)")

    # sr = gp.SpatialReference(32198)
    sr = gp.CreateObject("SpatialReference")
    wd = os.path.dirname(sys.argv[0])
    sr.CreateFromFile(os.path.join(wd, 'EPSG32198.prj'))

    XY_Layer = gp.MakeXYEventLayer_management(fc,Xname,Yname,"XY_Layer",sr)

    printit("Exportation de la couche temporaire de points vers votre destination")
    gp.CopyFeatures_management(XY_Layer,dest)

    printit("Ajout d'un index spatial sur la couche identifi�e par votre destination")
    gp.AddSpatialIndex_management(dest)

    printit("Ajout d'un index attributaire  (champ GEOCODE) sur la couche identifi�e par votre destination")
    gp.AddIndex_management (dest, "GEOCODE", "GEOCODE")


    printit("Suppression des champs temporaire X1 et Y1")

    # gp.DeleteField_management(dest,Xname)
    gp.DeleteField_management(fc,Xname)
    # gp.DeleteField_management(dest,Yname)
    gp.DeleteField_management(fc,Yname)


    endtime = time.time()
    elapsed = endtime - starttime
    printit (str(elapsed/60) + " minutes")


# Run the script
if __name__ == '__main__':

    #for x in range(500):
    main()








#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Louis-Pierre Couillard
# 2017

# Corrections:
# 2021-09 - Ajout de la fonction lancement_cmd (pointe vers gdal2.3.2 dans prerequis) et load2ogr_tblfinale pour le chargement de la table de résultats, execute_ogr ne fonctionnait plus (chargement s'arretait)
#         - Correction des étages SUP + INF (seulement 1 sur 2 sortait au pivot de la table etage.
# 2022-02 - Amélioration de l'interface et joint de table avec la couche des peuplements.
# 2024    - Ajout de la table biomasse et carbone.

import os
import sys
import sqlite3 as lite
import copy
import time
import subprocess
import tempfile
import shutil
import arcpy


def getscriptpath():
    return os.path.dirname(os.path.realpath(sys.argv[0]))

def lancement_cmd(cmd, return_output=False, gdalLocal= True, igoreError= False):
    """ JM 2018-12-02
    Fonction qu'on apelle pour lancer une commande par l'invite de commande
    Pour OGR
    PARAM:
        gdalLocal indique si le gdal indiquer dans la construction de object est utilisé. Si est=False, utilisera celui dans les variable environnement de l'ordinateur
        igoreError: Dans certain cas exemple gdaltindex ou on ne peux configurer le repertoire de plugins donnera des erreurs de DLL introuvable
            ERROR 1: Can't load requested DLL: C:\mrnmicro\applic\GDAL\2.3.2\gdalplugins\ogr_FileGDB.dll' \
                       '127: La procÚdure spÚcifiÚe est introuvable.
        Mais ceci n'est pas une erreur, donc on peux mettre le param a True pour eviter les erreur
    """
    if gdalLocal is True:
        cmd = """ {0}/{1} --CONFIG GDAL_DRIVER_PATH "{2}" """.format(os.path.join(getscriptpath(), "gdal2.3.2"),cmd, os.path.join(os.path.join(getscriptpath(), "gdal2.3.2"), "gdalplugins"))

    if isinstance(cmd, str):
        cmdByte = cmd
    else:
        cmdByte = cmd.encode('850')  # on convertie unicode en STR python2

    output = subprocess.check_output(cmdByte, stdin=None, stderr=subprocess.STDOUT, shell=True)
    #                                 # shell=True, universal_newlines=True)

    try:
        output = output.decode('utf-8', 'ignore') # reconversion byte -> unicode (python2)  byte -> str (python 3)

    except Exception as e:
        try:
            output = output.decode('850', 'ignore')
        except:
        #python 3 sur decode... passe
            pass

    if return_output:
        return output


def load2ogr(destformat, dest, destname, source, sourcelayer, destlayename=None, typegeom=None, epsg_dest=None, modeload='append', sql_param=None):
    """Prepare une commande de chargement de donnees a partir d'intrants SHP, GDB et SQLITE
    Configure pour fonctionner avec GDAL 1.11.3
    Args:
        destformat (str)    :[REQUIS]   Format de destination defini par la commmande OGR2OGR --formats
                                        [SQLITE,FileGDB,ESRI Shapefile]
        dest (str)          :[REQUIS]   Lieu d'exportation de la donnee en sortie
                                        "e:/tmp"
        destname (str)      :[REQUIS]   Nom de la donnee en sortie
                                        "export2ogr"
        source (str)        :[REQUIS]   Nom de la donnee a convertir
                                        SQLITE ==> "e:/tmp/export2ogr.sqlite"
                                        FileGDB ==> "e:/tmp/export2ogr.gdb"
                                        ESRI Shapefile ==> "E:/tmp/shp.shp"
        sourcelayer (str)    :[REQUIS]   Nom de la classe d'entitee a charger.
                                        Necessaire pour SQLITE et FileGDB
                                        SQLITE ==> "nomFC"
                                        FileGDB ==> "nomFC"
                                        ESRI Shapefile ==> None
        destlayename (str)  :[Optionel] Si valeur a None ou absente le nom de la source ou du sourcelayer
                                        est chargee comme nom de sortie.
                                        Si presente, renomme le nom de la couche de sortie
                                        None pour Esri Shapefile
        typegeom (str)      :[Optionel] Type de geometrie a charger.
                                        Si None le type de geometrie reste inchangee.
                                        Si 'table, exportation sans geometrie
                                        [None, table]
        epsg_dest (int)     :[Optionel] le # d'EPSG (http://spatialreference.org/)
                                        Si present, la donnee sera reprojetee.
                                        Si None, la donnee reste dans la projection d'origine
                                        [None, 32198, ...]
        modeload (str)      :[Optionel] Type d'action a effectuer par OGR2OGR
                                        Si None ou append on "append" a la destination la donnee intrante.
                                        Si update (TODO)
        sql_param (str)     :[Optionel] Clause SQL a ajouter a la commande OGR
                                        Si absente, la valeur est NONE et sera transpose en ""
                                        Si presente, on ajoute un element -SQL avant la syntaxe

    Returns:
        succes (boolean) :              Indique si l'operation de chargement par ogr2ogr a ete complete avec succes.
                                        True = succes
                                        False = echec
        erreur (str):                   Description de l'erreur retourne
                                        Vide si sans erreur (succes= True)
        cmd (str):                      commande lancee a ogr2ogr 1.11.3 (Debug)

    """
    dsco = ""
    if destformat == 'SQLITE':
        ext_dest = ".sqlite"
        dsco = " -dsco SPATIALITE=YES"
    elif destformat == 'FileGDB':
        ext_dest = ".gdb"
        dsco = "-dsco FGDB_BULK_LOAD=YES"
    elif destformat == 'ESRI Shapefile':
        ext_dest = ".shp"
    else:
        return False
    if destformat == 'SQLITE' and typegeom == 'table':
        dsco = ""

    if destlayename is not None:
        destlayename = " -nln %s" % destlayename
    else:
        destlayename = ""

    path_ogr_output = os.path.join(dest, destname+ext_dest)
    modeload = "-%s" % modeload
    if typegeom == 'table':
        typegeom = " -nlt NONE"
        epsg_dest = ""
    else:
        typegeom = ""
        if epsg_dest is not None:
            epsg_dest = " -t_srs EPSG:%s" % epsg_dest
        else:
            epsg_dest = ""

    ext_shp = ".shp"
    ext_gdb = ".gdb"

    if source.lower().find(ext_shp) != -1:
        # type shapefile
        if source.endswith(ext_shp):
            # print "ceci est un shape"
            sourcelayer = " "
    if source.lower().find(ext_gdb) != -1:
        if sourcelayer is not None:
            pass  # print "ceci est une geobase avec une FC"
        else:
            # print "ceci est une geobase SANS FC"
            pass
    if sql_param:
        sql_syntaxe = """-sql "%s" """ % sql_param
    else:
        sql_syntaxe = ""

    cmd = """ ogr2ogr -f "%s" %s "%s" "%s" %s %s %s %s %s %s -gt 200000 """ % (destformat, modeload, path_ogr_output, source,
                                                                        sourcelayer, destlayename, typegeom, dsco,
                                                                        epsg_dest,sql_syntaxe)
    succes, erreur = execute_ogr(cmd)

    return succes, erreur, cmd

def load2ogr_tblfinale(destformat, dest, destname, source, sourcelayer, destlayename=None, typegeom=None, epsg_dest=None, modeload='append', sql_param=None):

    ext_dest = ".gdb"
    dsco = "-dsco FGDB_BULK_LOAD=YES"

    if destlayename is not None:
        destlayename = " -nln %s" % destlayename
    else:
        destlayename = ""

    path_ogr_output = os.path.join(dest, destname+ext_dest)
    modeload = "-%s" % modeload
    if typegeom == 'table':
        typegeom = " -nlt NONE"
        epsg_dest = ""
    else:
        typegeom = ""
        if epsg_dest is not None:
            epsg_dest = " -t_srs EPSG:%s" % epsg_dest
        else:
            epsg_dest = ""

    ext_shp = ".shp"
    ext_gdb = ".gdb"

    if source.lower().find(ext_shp) != -1:
        # type shapefile
        if source.endswith(ext_shp):
            # print "ceci est un shape"
            sourcelayer = " "
    if source.lower().find(ext_gdb) != -1:
        if sourcelayer is not None:
            pass  # print "ceci est une geobase avec une FC"
        else:
            # print "ceci est une geobase SANS FC"
            pass
    if sql_param:
        sql_syntaxe = """-sql "%s" """ % sql_param
    else:
        sql_syntaxe = ""

    cmd = """ogr2ogr -f "%s" %s "%s" "%s" %s %s %s %s %s %s -gt 200000 """ % (destformat, modeload, path_ogr_output, source,
                                                                        sourcelayer, destlayename, typegeom, dsco,
                                                                        epsg_dest,sql_syntaxe)
    return cmd

def run_command(command):
    startupinfo = None
    if os.name == 'nt':
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    p = subprocess.Popen(command,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT,
                         startupinfo=startupinfo)
    return iter(p.stdout.readline())

def execute_ogr(cmd):
    """Prepare a partir d'une commande de chargement de donnees a configurer les call selon des chemins relatifs
    Configure pour fonctionner avec GDAL 1.11.3
    Args:
        cmd (str)    :[REQUIS]          Appel ogr2ogr pour CMD dos.
    Returns:
        succes (boolean) :              Indique si l'operation de chargement par ogr2ogr a ete complete avec succes.
                                        True = succes
                                        False = echec
        erreur (str):                   Description de l'erreur retourne
                                        Vide si sans erreur (succes= True)
    """

    cmd = cmd.lstrip()

    gdalpath = os.path.join(getscriptpath(), "gdal1113")
    gdalpath_driver = os.path.join(gdalpath, "gdalplugins")

    cmd2_local = os.path.join(gdalpath, cmd + """ --CONFIG GDAL_DRIVER_PATH "%s" """ % gdalpath_driver)
    erreur = ""
    succes = True

    for line in run_command(cmd2_local): #.encode('UTF-8')): ###########
        line = str(line) ################################################ Pour faire fonctionner en Python 3.6
        if line.startswith("F"):
            succes = False
            erreur += line.replace("\n", "").replace("\r", "")
            break
        if not line.startswith('  ->'):
            if len(erreur) > 0:
                erreur += line.replace("\n", "").replace("\r", "")
    return succes, erreur

def executesql(cmdsql):
    conlocal = None
    succes = False

    try:
        conlocal = lite.connect(pathspatialite)
        cur = conlocal.cursor()
        cur.execute(cmdsql)
        conlocal.commit()
        succes = True
    except:
        succes = False
    finally:
        if conlocal:
            conlocal.close()
        return succes

def dict_from_nom_chams_sqlite(pathsqlite, table):
    di_champs = dict()
    li_ordre_champs = list()
    con = None
    try:
        con = lite.connect(pathsqlite)
        con.row_factory = lite.Row  # IMPORTANT POUR CRÉER LISTE
        cur = con.cursor()

        cur.execute('PRAGMA table_info(%s);' % table)

        rows = cur.fetchall()
        row = None
        for row in rows:
            li_ordre_champs.append(row[1])
            # arcpy.AddMessage(row[1])
            di_champs[row[1]] = ""
        del row, rows
    except:
        pass

    finally:
        if con:
            con.close()
        return di_champs, li_ordre_champs

def csvtodict(chemincsv,nom1erchamp='nom'):
    """
    Auteur: Pierre-Etienne Lord
    Date creation : 2016-04-12
    Cette fonction permet de convertir un fichier CSV en dictionnaire python.
    Fonctionne avec python 2.6 + et permet de gerer si votre separateur de champ est un ";".
    Automatiquement, il fait la gestion de ";" vers "," vers un repertoire temporaire..

    Args:
        chemincsv (str): Parametre de chemin d'acces du fichier csv a convertir.
        nom1erchamp (str): nom du premier champ qui sert de clef pour chacune ces lignes du csv.
    Returns:
        di_return (dict): Le dictionnaire retourne avec le contenu du CSV transpose.

    exemple d'Appel: di_nom_produits_ieqm = csvtodict("\\path\vers\csv.csv,'nomdupremierchamp')
    """
    import csv

    di_return = dict()
    reader = ""
    try:
        reader = csv.DictReader(open(chemincsv))
        di_return = {}
        for row in reader:
            key = row.pop(nom1erchamp)
            if key in di_return:
                # implement your duplicate row handling here
                pass
            di_return[key] = row
        del reader
    except KeyError:
        del reader
        from tempfile import mkdtemp
        from shutil import rmtree

        temp_dir = mkdtemp()

        nouv = "%s\%s.tmp" % (temp_dir, os.path.basename(chemincsv))
        f1 = open(chemincsv, 'r')
        f2 = open(nouv, 'w')
        for line in f1:
            f2.write(line.replace(';', ','))
        f1.close()
        f2.close()
        di_return = csvtodict(nouv, nom1erchamp)
        rmtree(temp_dir)

    return di_return


def main():
    global debug
    wd = os.path.dirname(sys.argv[0])
    prerequis = os.path.join(wd, "gdal1113")
    gdb10prequis = os.path.join(wd, "gdb10.gdb")

    if not os.path.exists(prerequis):
        sys.exit("Les prerequis a l'outils sont absent dans le repertoire de l'outil. Veuillez aller rechercher l'outil en vous assurant de faire suivre le repertoire PREREQUIS")
    if not os.path.exists(gdb10prequis):
        sys.exit("Les prerequis a l'outils sont absent dans le repertoire de l'outil. Veuillez aller rechercher l'outil en vous assurant de faire suivre le repertoire PREREQUIS")

    #  CONSTANTES
    li_codes = [
        ### Codes Non-commerciaux ENLEVER QUAND TIGES ET GAULES SONT ABSENTS
        {"code_outil": "Non-commerciales", "code_cmp": "AEH", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "AME", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "AUC", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "AUR", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "CAR", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "CEO", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "COA", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "COC", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "CRA", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "ERE", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "ERG", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "ERP", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "JUV", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "MAS", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "PRP", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "PRV", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "RHS", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "RHT", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "SAL", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "SOA", "code_carto": ""},
        {"code_outil": "Non-commerciales", "code_cmp": "SOD", "code_carto": ""},

        ### Codes essences table ESSENCES
        {"code_outil": "BG-->Bouleau_gris", "code_cmp": "", "code_carto": "BG"},
        {"code_outil": "BJ-->Bouleau_jaune", "code_cmp": "", "code_carto": "BJ"},
        {"code_outil": "BP-->Bouleau_a_papier", "code_cmp": "", "code_carto": "BP"},
        {"code_outil": "CC-->Caryer_cordiforme", "code_cmp": "", "code_carto": "CC"},
        {"code_outil": "CT-->Cerisier_tardif", "code_cmp": "", "code_carto": "CT"},
        {"code_outil": "CB-->Chene_blanc", "code_cmp": "", "code_carto": "CB"},
        {"code_outil": "CG-->Chene_gros_fruits", "code_cmp": "", "code_carto": "CG"},
        {"code_outil": "CR-->Chene_rouge", "code_cmp": "", "code_carto": "CR"},
        {"code_outil": "EB-->Epinette_blanche", "code_cmp": "", "code_carto": "EB"},
        {"code_outil": "EN-->Epinette_noire", "code_cmp": "", "code_carto": "EN"},
        {"code_outil": "EV-->Epinette_de_Norvege", "code_cmp": "", "code_carto": "EV"},
        {"code_outil": "EU-->Epinette_rouge", "code_cmp": "", "code_carto": "EU"},
        {"code_outil": "EA-->Erable_argente", "code_cmp": "", "code_carto": "EA"},
        {"code_outil": "EO-->Erable_rouge", "code_cmp": "", "code_carto": "EO"},
        {"code_outil": "ES-->Erable_a_sucre", "code_cmp": "", "code_carto": "ES"},
        {"code_outil": "FA-->Frene_dAmerique", "code_cmp": "", "code_carto": "FA"},
        {"code_outil": "FO-->Frene_noir", "code_cmp": "", "code_carto": "FO"},
        {"code_outil": "FP-->Frene_de_Pennsylvanie", "code_cmp": "", "code_carto": "FP"},
        {"code_outil": "HG-->Hetre", "code_cmp": "", "code_carto": "HG"},
        {"code_outil": "MH-->Meleze_hybride", "code_cmp": "", "code_carto": "MH"},
        {"code_outil": "MJ-->Meleze_japonais", "code_cmp": "", "code_carto": "MJ"},
        {"code_outil": "ML-->Meleze_laricin", "code_cmp": "", "code_carto": "ML"},
        {"code_outil": "ME-->Meleze_europeen", "code_cmp": "", "code_carto": "ME"},
        {"code_outil": "NC-->Noyer_cendre", "code_cmp": "", "code_carto": "NC"},
        {"code_outil": "NN-->Noyer_noir", "code_cmp": "", "code_carto": "NN"},
        {"code_outil": "OA-->Orme_dAmerique", "code_cmp": "", "code_carto": "OA"},
        {"code_outil": "OV-->Ostryer_de_Virginie", "code_cmp": "", "code_carto": "OV"},
        {"code_outil": "PA-->Peuplier_baumier", "code_cmp": "", "code_carto": "PA"},
        {"code_outil": "PL-->Peuplier_deltoide", "code_cmp": "", "code_carto": "PL"},
        {"code_outil": "PD-->Peuplier_grandes_dents", "code_cmp": "", "code_carto": "PD"},
        {"code_outil": "PH-->Peuplier_hybride", "code_cmp": "", "code_carto": "PH"},
        {"code_outil": "PT-->Peuplier_faux_tremble", "code_cmp": "", "code_carto": "PT"},
        {"code_outil": "PB-->Pin_blanc", "code_cmp": "", "code_carto": "PB"},
        {"code_outil": "PC-->Pin_rigide", "code_cmp": "", "code_carto": "PC"},
        {"code_outil": "PG-->Pin_gris", "code_cmp": "", "code_carto": "PG"},
        {"code_outil": "PR-->Pin_rouge", "code_cmp": "", "code_carto": "PR"},
        {"code_outil": "PS-->Pin_sylvestre", "code_cmp": "", "code_carto": "PS"},
        {"code_outil": "PU-->Pruche", "code_cmp": "", "code_carto": "PU"},
        {"code_outil": "SB-->Sapin", "code_cmp": "", "code_carto": "SB"},
        {"code_outil": "TO-->Thuya", "code_cmp": "", "code_carto": "TO"},
        {"code_outil": "TA-->Tilleul", "code_cmp": "", "code_carto": "TA"},
        ### Combinaisons d'essences
        {"code_outil": "CH-->Combinaison_Chenes", "code_cmp": "", "code_carto": "CH"},
        {"code_outil": "EP-->Epinettes_noire_rouge", "code_cmp": "", "code_carto": "EP"},
        {"code_outil": "ER-->Combinaison_Erables", "code_cmp": "", "code_carto": "ER"},
        {"code_outil": "PE-->Combinaison_Peupliers", "code_cmp": "", "code_carto": "PE"},
        {"code_outil": "OR-->Combinaison_Ormes", "code_cmp": "", "code_carto": "OR"},
        {"code_outil": "FH-->Feuillus_sur_station_humide", "code_cmp": "", "code_carto": "FH"},
        {"code_outil": "FI-->Feuillus_intolerants", "code_cmp": "", "code_carto": "FI"},
        {"code_outil": "FN-->Feuillus_non_commerciaux", "code_cmp": "", "code_carto": "FN"},
        {"code_outil": "FR-->Combinaison_Frenes", "code_cmp": "", "code_carto": "FR"},
        {"code_outil": "FT-->Feuillus_tolerants", "code_cmp": "", "code_carto": "FT"},
        {"code_outil": "FX-->Feuillus_indetermines", "code_cmp": "", "code_carto": "FX"},
        {"code_outil": "FZ-->Feuillus_indetermines_plantation", "code_cmp": "", "code_carto": "FZ"},
        {"code_outil": "PI-->Combinaison_Pins", "code_cmp": "", "code_carto": "PI"},
        {"code_outil": "RX-->Resineux_indetermines", "code_cmp": "", "code_carto": "RX"},
        {"code_outil": "RZ-->Resineux_indetermines_plantation", "code_cmp": "", "code_carto": "RZ"},
        {"code_outil": "SE-->Sapin+Epinette_blanche", "code_cmp": "", "code_carto": "SE"},

        ### Codes tables TIGES et GAULES
        ### Combinaisons
        {"code_outil": "BOU-->GAT_Bouleaux", "code_cmp": "BOU", "code_carto": ""},
        {"code_outil": "ER-->GAT_Erables", "code_cmp": "ER", "code_carto": ""},
        {"code_outil": "PE-->GAT_Peupliers", "code_cmp": "PE", "code_carto": ""},
        {"code_outil": "FD-->GAT_Autres_feuillus_durs", "code_cmp": "FD", "code_carto": ""},
        {"code_outil": "PBPR-->GAT_Pin_blanc_et_rouge", "code_cmp": "PBPR", "code_carto": ""},
        {"code_outil": "SEPM-->GAT_Sapin_Epinette_Pin-gris_Meleze", "code_cmp": "SEPM", "code_carto": ""},
        {"code_outil": "FEU-->Tous_feuillus", "code_cmp": "FEU", "code_carto": ""},
        {"code_outil": "RES-->Tous_resineux", "code_cmp": "RES", "code_carto": ""},
        {"code_outil": "TOT-->Toutes_essences", "code_cmp": "TOT", "code_carto": ""},

        {"code_outil": "BOG-->Bouleau_gris", "code_cmp": "BOG", "code_carto": ""},
        {"code_outil": "BOJ-->Bouleau_jaune", "code_cmp": "BOJ", "code_carto": ""},
        {"code_outil": "BOP-->Bouleau_a_papier", "code_cmp": "BOP", "code_carto": ""},
        {"code_outil": "CAC-->Caryer_cordiforme", "code_cmp": "CAC", "code_carto": ""},
        {"code_outil": "CET-->Cerisier_tardif", "code_cmp": "CET", "code_carto": ""},
        {"code_outil": "CHB-->Chene_blanc", "code_cmp": "CHB", "code_carto": ""},
        {"code_outil": "CHG-->Chene_gros_fruits", "code_cmp": "CHG", "code_carto": ""},
        {"code_outil": "CHR-->Chene_rouge", "code_cmp": "CHR", "code_carto": ""},
        {"code_outil": "EPB-->Epinette_blanche", "code_cmp": "EPB", "code_carto": ""},
        {"code_outil": "EPN-->Epinette_noire", "code_cmp": "EPN", "code_carto": ""},
        {"code_outil": "EPO-->Epinette_de_Norvege", "code_cmp": "EPO", "code_carto": ""},
        {"code_outil": "EPR-->Epinette_rouge", "code_cmp": "EPR", "code_carto": ""},
        {"code_outil": "ERA-->Erable_argente", "code_cmp": "ERA", "code_carto": ""},
        {"code_outil": "ERR-->Erable_rouge", "code_cmp": "ERR", "code_carto": ""},
        {"code_outil": "ERS-->Erable_a_sucre", "code_cmp": "ERS", "code_carto": ""},
        {"code_outil": "FRA-->Frene_dAmerique", "code_cmp": "FRA", "code_carto": ""},
        {"code_outil": "FRN-->Frene_noir", "code_cmp": "FRN", "code_carto": ""},
        {"code_outil": "FRP-->Frene_de_Pennsylvanie", "code_cmp": "FRP", "code_carto": ""},
        {"code_outil": "HEG-->Hetre", "code_cmp": "HEG", "code_carto": ""},
        {"code_outil": "MEH-->Meleze_hybride", "code_cmp": "MEH", "code_carto": ""},
        {"code_outil": "MEJ-->Meleze_japonais", "code_cmp": "MEJ", "code_carto": ""},
        {"code_outil": "MEL-->Meleze_laricin", "code_cmp": "MEL", "code_carto": ""},
        {"code_outil": "MEU-->Meleze_europeen", "code_cmp": "MEU", "code_carto": ""},
        {"code_outil": "NOC-->Noyer_cendre", "code_cmp": "NOC", "code_carto": ""},
        {"code_outil": "NON-->Noyer_noir", "code_cmp": "NON", "code_carto": ""},
        {"code_outil": "ORA-->Orme_dAmerique", "code_cmp": "ORA", "code_carto": ""},
        {"code_outil": "OSV-->Ostryer_de_Virginie", "code_cmp": "OSV", "code_carto": ""},
        {"code_outil": "PEB-->Peuplier_baumier", "code_cmp": "PEB", "code_carto": ""},
        {"code_outil": "PED-->Peuplier_deltoide", "code_cmp": "PED", "code_carto": ""},
        {"code_outil": "PEG-->Peuplier_grandes_dents", "code_cmp": "PEG", "code_carto": ""},
        {"code_outil": "PEH-->Peuplier_hybride", "code_cmp": "PEH", "code_carto": ""},
        {"code_outil": "PET-->Peuplier_faux_tremble", "code_cmp": "PET", "code_carto": ""},
        {"code_outil": "PIB-->Pin_blanc", "code_cmp": "PIB", "code_carto": ""},
        {"code_outil": "PID-->Pin_rigide", "code_cmp": "PID", "code_carto": ""},
        {"code_outil": "PIG-->Pin_gris", "code_cmp": "PIG", "code_carto": ""},
        {"code_outil": "PIR-->Pin_rouge", "code_cmp": "PIR", "code_carto": ""},
        {"code_outil": "PIS-->Pin_sylvestre", "code_cmp": "PIS", "code_carto": ""},
        {"code_outil": "PRU-->Pruche", "code_cmp": "PRU", "code_carto": ""},
        {"code_outil": "SAB-->Sapin", "code_cmp": "SAB", "code_carto": ""},
        {"code_outil": "THO-->Thuya", "code_cmp": "THO", "code_carto": ""},
        {"code_outil": "TIL-->Tilleul", "code_cmp": "TIL", "code_carto": ""},

        ### Table PRODUCTIVITE
        {"code_outil": "AFI-->FI_sauf_BOP_PET", "code_cmp": "AFI", "code_carto": ""},
        {"code_outil": "AFT-->FT_sauf_BOJ_ERR_ERS", "code_cmp": "AFT", "code_carto": ""},
        {"code_outil": "ART-->Resineux_EPO_EPR_PIB_PRU", "code_cmp": "ART", "code_carto": ""},
        {"code_outil": "PEX-->Peupliers", "code_cmp": "PEX", "code_carto": ""}]

    li_codes_outil = list()
    li_code_carto = list()
    li_code_cmp = list()

    for dict_codes in li_codes:
        if dict_codes['code_outil'] not in li_codes_outil and len(dict_codes['code_outil']) > 0:
            li_codes_outil.append(dict_codes['code_outil'])
        if dict_codes['code_carto'] not in li_code_carto and len(dict_codes['code_carto']) > 0:
            li_code_carto.append(dict_codes['code_carto'])
        if dict_codes['code_cmp'] not in li_code_cmp and len(dict_codes['code_cmp']) > 0:
            li_code_cmp.append(dict_codes['code_cmp'])

    global pathspatialite
    di_elem_joindre = dict()

    ce_join_1 = arcpy.GetParameterAsText(0)
    table_etage = arcpy.GetParameterAsText(1)
    table_essence = arcpy.GetParameterAsText(2)
    codes_tbl_essence = arcpy.GetParameterAsText(3)
    var_etage = arcpy.GetParameterAsText(4)
    table_gaule = arcpy.GetParameterAsText(5)
    table_tige = arcpy.GetParameterAsText(6)
    codes_tbl_tige_gaule = arcpy.GetParameterAsText(7)
    table_prod_pot = arcpy.GetParameterAsText(8)
    codes_tbl_prod_pot = arcpy.GetParameterAsText(9)
    table_prop_bois = arcpy.GetParameterAsText(10)
    codes_tbl_prop_bois = arcpy.GetParameterAsText(11)
    var_dendro = arcpy.GetParameterAsText(12)
    nom_geoc = arcpy.GetParameterAsText(13)
    dest_gdb_path = arcpy.GetParameterAsText(14)
    nom_tbl_pivotee = arcpy.GetParameterAsText(15)
    champs_export = arcpy.GetParameterAsText(16)
    table_meta = arcpy.GetParameterAsText(17)
    table_climat = arcpy.GetParameterAsText(18)
    table_contraintes = arcpy.GetParameterAsText(19)
    table_stations = arcpy.GetParameterAsText(20)
    table_classi_eco = arcpy.GetParameterAsText(21)
    table_biomasse = arcpy.GetParameterAsText(22)
    champs_autres = arcpy.GetParameterAsText(23)
    reptrav = tempfile.mkdtemp()
    debug = False
    if debug:
        reptrav = "D:/temp"

    try:
        arcpy.UpgradeGDB_management(dest_gdb_path)
    except:
        pass

    #### Renvoi de la couche et des tables a pivoter dans une gdb 10.0
    if ce_join_1.lower().find(".gdb") != -1:
        arcpy.CreateFileGDB_management(reptrav, "gdb10", "10.0")
        pathgdb10 = os.path.join(reptrav, "gdb10.gdb")

        ce_join_1.replace("\\", "/")
        arcpy.Copy_management(ce_join_1, os.path.join(pathgdb10, os.path.basename(ce_join_1)))

        ### COPIE DE LA COUCHE D'ENTITES EN ENTREE DANS LA GDB DE SORTIE ET QUI SERA JOINTE A LA TABLE PIVOTEE (JOINT A LIGNE 1125 ENVIRON)
        tbl_joint_gdb = os.path.join(dest_gdb_path, nom_tbl_pivotee + "_joint")
        arcpy.CopyFeatures_management(ce_join_1, tbl_joint_gdb)

        ce_join_1 = os.path.join(pathgdb10, os.path.basename(ce_join_1))

        if table_etage != "":
            table_etage = os.path.join(pathgdb10, os.path.basename(table_etage))
        if table_essence != "":
            table_essence = os.path.join(pathgdb10, os.path.basename(table_essence))
        if table_tige != "":
            table_tige = os.path.join(pathgdb10, os.path.basename(table_tige))
        if table_gaule != "":
            table_gaule = os.path.join(pathgdb10, os.path.basename(table_gaule))
        if table_prop_bois != "":
            table_prop_bois = os.path.join(pathgdb10, os.path.basename(table_prop_bois))
        if table_prod_pot != "":
            table_prod_pot = os.path.join(pathgdb10, os.path.basename(table_prod_pot))

    #########################

    #if debug:
    arcpy.AddMessage(reptrav)

    li_var_etage_intrant = list()
    if var_etage.startswith('SI'):
        li_var_etage_intrant = ["SUP", "INF"]
    elif var_etage.startswith('SUP'):
        li_var_etage_intrant = ["SUP"]
    elif var_etage.startswith('INF'):
        li_var_etage_intrant = ["INF"]

    intrant_lier_etage = len(table_essence) + len(table_etage)
    if intrant_lier_etage == 0:
        li_var_etage_intrant = list()

    try:
        release = arcpy.Describe(dest_gdb_path).release
    except:
        release = "2,3,0"

    if release == "2,3,0":
        gdb_version = '9.3'
    elif release == "3,0,0":
        gdb_version = '10'
    else:
        gdb_version = '9.3'

    if debug:
        arcpy.AddWarning(gdb_version)

    if gdb_version == '9.3':
        arcpy.AddMessage("L'outil est compatible et les tests sont effectues a partir de la version 10 de ArcGIS. Si vous utilisez la version 9.3, veuillez vérifier que les champs pivotes ne soient pas a NULL.")

    champpk = nom_geoc
    pk_flat = "%s" % champpk
    dest_table_flat = ""

    li_coalesce = ["TIGE_HA", "ST_HA", "VMB_HA", "ST_ESS_PC"]

    try:
        di_produits_ieqm = {'tige': {'path': table_tige,
                                     'codes': li_code_cmp,
                                     'pivot': {'nom': 'aj_tige_flat', 'champpk': 'OGC_FID', 'champpivot': 'CO_CMP'},
                                     'relat': {'nom': 'tige_relationel',  'champpk': 'OGC_FID'},
                                     'var': [{'TIGE_HA': {'alias': 'TI_HA', 'type': 'DOUBLE PRECISION'}},
                                             {'ST_HA': {'alias': 'ST_HA', 'type': 'DOUBLE PRECISION'}},
                                             {'VMB_HA': {'alias': 'VM_HA', 'type': 'DOUBLE PRECISION'}},
                                             {'VMB_TIGE': {'alias': 'VM_TI', 'type': 'DOUBLE PRECISION'}},
                                             {'DHPQ': {'alias': 'DHPQ', 'type': 'DOUBLE PRECISION'}}]},
                            'gaule':
                                {'path': table_gaule,
                                 'codes': li_code_cmp,
                                 'pivot': {'nom': 'aj_gaule_flat', 'champpk': 'OGC_FID', 'champpivot': 'CO_CMP'},
                                 'relat': {'nom': 'gaule_relationel',  'champpk': 'OGC_FID'},
                                 'var': [
                                     {'TIGE_HA': {'alias': 'TI_HA_GL', 'type': 'DOUBLE PRECISION'}},
                                     {'ST_HA': {'alias': 'ST_HA_GL', 'type': 'DOUBLE PRECISION'}}]
                                 },
                            'essence':
                                {'path': table_essence,
                                 'codes': li_code_carto,
                                 'pivot': {'nom': 'aj_essence_flat', 'champpk': 'OGC_FID', 'champpivot': 'concat_pivot'},
                                 'relat': {'nom': 'essence_relationel',  'champpk': 'OGC_FID'},
                                 'var': [
                                     {'ST_ESS_PC': {'alias': 'PC', 'type': 'SHORT'}}]
                                 },
                            'etage':
                                {'path': table_etage,
                                 'codes': li_code_carto,
                                 'pivot': {'nom': 'aj_etage_flat', 'champpk': 'OGC_FID', 'champpivot': 'ETAGE'},
                                 'relat': {'nom': 'etage_relationel',  'champpk': 'OGC_FID'},
                                 'var': [
                                     {'TY_COUV_ET': {'alias': 'TYPE_C', 'type': "VARCHAR_2"}},
                                     {'DENSITE': {'alias': 'DENSIT', 'type': 'SHORT'}},
                                     {'HAUTEUR': {'alias': 'HAUT', 'type': 'SHORT'}},
                                     {'CL_AGE_ET': {'alias': 'CL_AGE', 'type': 'VARCHAR_5'}},
                                     {'ETA_ESS_PC': {'alias': 'ETA_PC', 'type': 'VARCHAR_28'}}]
                                 },
                            'productivite_pot':
                                {'path': table_prod_pot,
                                 'codes': li_code_cmp,
                                 'pivot': {'nom': 'aj_prodpot_flat', 'champpk': 'OGC_FID', 'champpivot': 'ESSENCE'},
                                 'relat': {'nom': 'prodpot_relationel',  'champpk': 'OGC_FID'},
                                 'var': [
                                     {'IQS_POT': {'alias': 'IQS', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_IQS_INF': {'alias': 'IQ_INF', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_IQS_SUP': {'alias': 'IQ_SUP', 'type': 'DOUBLE PRECISION'}},
                                     {'ACCRST_POT': {'alias': 'ACCR', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_AST_INF': {'alias': 'AC_INF', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_AST_SUP': {'alias': 'AC_SUP', 'type': 'DOUBLE PRECISION'}}]
                                 },
                            'proprietes_bois':
                                {'path': table_prop_bois,
                                 'codes': li_code_cmp,
                                 'pivot': {'nom': 'aj_propbois_flat', 'champpk': 'OGC_FID', 'champpivot': 'ESSENCE'},
                                 'relat': {'nom': 'propbois_relationel', 'champpk': 'OGC_FID'},
                                 'var': [
                                     {'DEN': {'alias': 'DEN', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_DEN_INF': {'alias': 'DE_INF', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_DEN_SUP': {'alias': 'DE_SUP', 'type': 'DOUBLE PRECISION'}},
                                     {'MOE': {'alias': 'MOE', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_MOE_INF': {'alias': 'ME_INF', 'type': 'DOUBLE PRECISION'}},
                                     {'IC_MOE_SUP': {'alias': 'ME_SUP', 'type': 'DOUBLE PRECISION'}}]
                                 }
                            }

        if len(codes_tbl_essence) + len(codes_tbl_tige_gaule) + len(codes_tbl_prod_pot) + len(codes_tbl_prop_bois) + intrant_lier_etage == 0:
            arcpy.AddWarning("aucun essence/groupement/etage a traiter selon les intrants/choix effectues")
            sys.exit()

        if len(codes_tbl_essence) == 0:
            codes_tbl_essence = "$$"
        if len(codes_tbl_tige_gaule) == 0:
            codes_tbl_tige_gaule = "$$"
        if len(codes_tbl_prod_pot) == 0:
            codes_tbl_prod_pot = "$$"
        if len(codes_tbl_prop_bois) == 0:
            codes_tbl_prop_bois = "$$"

        var_ess_group = "%s;%s;%s;%s" % (codes_tbl_essence, codes_tbl_tige_gaule, codes_tbl_prod_pot, codes_tbl_prop_bois)
        var_ess_group = var_ess_group.replace(";$$,", ";").replace("$$;", "").replace(";$$", "")
        li_var_essence_group_code_outils = var_ess_group.split(";")
        li_var_essence_group = list()

        for codes_demandes in li_var_essence_group_code_outils:
            for codes_possible in li_codes:
                if codes_demandes == codes_possible['code_outil']:
                    if codes_possible['code_cmp'] not in li_var_essence_group and len(codes_possible['code_cmp']) > 0:
                        li_var_essence_group.append(codes_possible['code_cmp'])
                    if codes_possible['code_carto'] not in li_var_essence_group and len(codes_possible['code_carto']) > 0:
                        li_var_essence_group.append(codes_possible['code_carto'])

        li_var_dendro = var_dendro.split(";")
        if debug:
            arcpy.AddWarning(li_var_essence_group)

        localtime = time.localtime()
        uuid_pivot = time.strftime("%Y%m%d_%Hh%Mm%Ssec", localtime)
        sqlitename_sansext = "pivot_%s" % uuid_pivot
        sqlitename = "pivot_%s.sqlite" % uuid_pivot
        gdbname_pivot_sansext = sqlitename_sansext
        gdbname_pivot = "pivot_%s.gdb" % uuid_pivot
        pathspatialite = os.path.join(reptrav, sqlitename)
        pathgdb_pivot = os.path.join(reptrav, gdbname_pivot)
        if len(nom_tbl_pivotee) > 0:
            tbl_name = "%s" % nom_tbl_pivotee
        else: ############ si le parametre de nom de table pivotee redevient facultatif
            tbl_name = "IEQM_FichierPlat_%s" % uuid_pivot
        dest_table_flat = os.path.join(dest_gdb_path, tbl_name)

        shutil.copytree(gdb10prequis, os.path.join(reptrav, gdbname_pivot))

        tabletransit_gdb = "join_tous"
        dest_table_flat_transit = os.path.join(reptrav, gdbname_pivot, tabletransit_gdb)

        if gdb_version == "9.3":
            arcpy.CreateTable_management(dest_gdb_path, tbl_name, "#", "#")
            arcpy.AddField_management(dest_table_flat, pk_flat, "TEXT", "", "", "21", "", "NON_NULLABLE", "REQUIRED", "")
        elif str(sys.version_info[0])+str(sys.version_info[1]) == "25" and gdb_version == "10":
            sql_ctable = """ogrinfo "%s" -sql "create table %s (OBJECTID OBJECTID, %s VARCHAR(21) NOT NULL)" """ % (dest_gdb_path, tbl_name, pk_flat)
            execute_ogr(sql_ctable)
        else:
            arcpy.CreateTable_management(dest_gdb_path, tbl_name, "#", "#")
            arcpy.AddField_management(dest_table_flat, pk_flat, "TEXT", "", "", "21", "", "NON_NULLABLE", "REQUIRED", "")

        ext = ""
        if ce_join_1.lower().endswith(".shp"):
            srcload = ce_join_1
            srclyn = None
        else:
            if ce_join_1.lower().find(".db") != -1:
                ext = ".db"
            if ce_join_1.lower().find(".gdb") != -1:
                ext = ".gdb"
            if ce_join_1.lower().find(".sqlite") != -1:
                ext = ".sqlite"

            srcload = ce_join_1.lower().split(ext)[0]+ext
            srclyn = os.path.basename(ce_join_1)

        # Chargement de la liste de PK dans le fichier SQLITE

        succes_li_pk, err_li_pk, cmd_li_pk = load2ogr("SQLITE", reptrav, sqlitename_sansext, srcload, srclyn, "tbl_li_pk", 'table', None, 'append', "select {0} from %s".format(nom_geoc) % srclyn)

        if succes_li_pk is False:
            arcpy.AddError(err_li_pk)
            arcpy.AddError(cmd_li_pk)
            sys.exit()

        # VALIDATION DES INTRANTS VOLET DENDRO
        di_traitement_ieqm = copy.deepcopy(di_produits_ieqm)
        di_traitement_ieqm['tige']['var'] = list()
        di_traitement_ieqm['gaule']['var'] = list()
        di_traitement_ieqm['productivite_pot']['var'] = list()
        di_traitement_ieqm['proprietes_bois']['var'] = list()
        di_traitement_ieqm['etage']['var'] = list()
        di_traitement_ieqm['essence']['var'] = list()

        for produit, dict_produits in list(di_produits_ieqm.items()):

            if len(dict_produits['path']) == 0 or dict_produits['path'] == "#":
                del di_traitement_ieqm[produit]
            else:

                for varsIEQM in dict_produits['var']:
                    if (list(varsIEQM.keys())[0] in li_var_dendro) and varsIEQM in di_produits_ieqm[produit]['var']:
                        if varsIEQM not in di_traitement_ieqm[produit]['var']:
                            di_traitement_ieqm[produit]['var'].append(varsIEQM)

        if di_traitement_ieqm == {}:
            arcpy.AddError("AUCUN ELEMENT A TRAITER")
            sys.exit("AUCUN ELEMENT A TRAITER")

        li_succes_traitements = list()
        if debug:
            arcpy.AddWarning(di_traitement_ieqm)
        # /////////////////////////////////////
        # Boucle pour chacun des produits relationnels selon les intrant de l'usager
        cnt_rel = 100
        executesql("PRAGMA synchronous = 0")

        for produit, dict_prod in list(di_traitement_ieqm.items()):
            arcpy.AddMessage(" ")
            arcpy.AddMessage(" ")
            arcpy.AddMessage("======================================================")
            arcpy.AddMessage("Traitement de la table %s" % produit)
            arcpy.AddMessage("======================================================")

            # /////////////////////////////
            # Config des intrants pour le OGR2OGR
            table_gdb_path = os.path.dirname(dict_prod['path'])
            table_tablename_ori = os.path.basename(dict_prod['path'])
            table_tablename_trv = dict_prod['relat']['nom']
            # gdbname = os.path.basename(table_gdb_path)

            succes_rel, err_rel, cmd_rel = load2ogr("SQLITE", reptrav, sqlitename_sansext, table_gdb_path,
                                                    table_tablename_ori, table_tablename_trv,
                                                    'table', None, 'append')
            li_var_essence_group_tmp = list(li_var_essence_group)

            if produit == 'essence':
                sql_alter = """ ALTER TABLE "%s" ADD COLUMN %s TEXT""" % (dict_prod['relat']['nom'], dict_prod['pivot']['champpivot'])
                sql_update = """ update "%s" set %s = "essence"||'_'||"etage" """ % (dict_prod['relat']['nom'], dict_prod['pivot']['champpivot'])

                executesql(sql_alter)
                executesql(sql_update)
                li_var_etage = list(li_var_etage_intrant)

                for elem in li_var_essence_group:
                    for eta in li_var_etage:
                        li_var_essence_group_tmp.append("%s_%s" % (elem, eta))

            # Gerer les categorie de cmp TOT.
            if produit in ('tige', 'gaule', 'iqb'):
                sql_update = """ update "%s" set co_cmp = 'TOT' where cat_co_cmp = 'TOT'""" % dict_prod['relat']['nom']
                executesql(sql_update)

            # Check PIVOTS possible.
            con = None
            try:
                con = lite.connect(pathspatialite)
                con.row_factory = lite.Row  # IMPORTANT POUR CRÉER LISTE
                cur = con.cursor()
                li_var_essence_group_prod=list()
                if produit in "etage":
                    li_var_essence_group_prod = list(li_var_etage_intrant)

                else:
                    li_var_essence_group_prod = list()
                if produit in "essence":
                    tri = " order by essence"
                else:
                    tri = ""

                sql = 'SELECT distinct(%s) from %s%s' % (dict_prod['pivot']['champpivot'], table_tablename_trv, tri)
                if debug:
                    arcpy.AddMessage(sql)
                cur.execute(sql)
                rows = cur.fetchall()
                row = None
                for row in rows:
                    if debug:
                        arcpy.AddWarning(str(len(li_var_essence_group_prod)) + " "+str(li_var_essence_group_prod)+ " " +  row[0])
                    if row[0] in li_var_essence_group_tmp:
                        li_var_essence_group_prod.append(row[0])
                del row, rows
            except:
                pass
            finally:
                if con:
                    con.close()

            if produit == 'tige': ### Pour eviter d'avoir PRU et PU, THO et TO dans pivot tiges. Meme resultat, doublon inutile.
                if 'TO' in li_var_essence_group_prod:
                    li_var_essence_group_prod.remove('TO')
                if 'PU' in li_var_essence_group_prod:
                    li_var_essence_group_prod.remove('PU')

            if len(li_var_essence_group_prod) == 0:
                arcpy.AddWarning("     Aucune essences/groupements d'essences/etages applicable selon les parametres selectionnes")
            else:
                # /////////////////////////////
                # Création de la table sous ARCGIS
                if debug:
                    arcpy.AddWarning(dict_prod['var'])
                if len(dict_prod['var']) == 0:
                    arcpy.AddWarning("     Aucune variable applicable pour cette table selon les parametres selectionnes")

                else:
                    if len(li_var_essence_group_prod) > 0:

                        ### Trier l'ordre des champs, etage SUP d'abord, INF a la fin
                        li_var_essence_group_prod.sort(key=lambda caract: caract[-1], reverse=True)

                        arcpy.AddMessage("     Les essences/groupements d'essences/etages suivantes vont etres pivotes")
                        arcpy.AddMessage("     " + str(li_var_essence_group_prod).replace("u'", "'").replace("[", "").replace("]", "").replace("'", ""))

                    for varsIEQM in dict_prod['var']:
                        val_vardendro = list(varsIEQM.keys())[0]
                        val_vardendro_alias = varsIEQM[val_vardendro]['alias']

                        if debug:
                            arcpy.AddWarning(varsIEQM)

                        for ess in li_var_essence_group_prod:
                            cle = "%s_%s_%s" % (ess, list(varsIEQM.keys())[0], produit.upper())
                            cle = "%s_%s" % (val_vardendro_alias, ess)
                            type_champ = varsIEQM[list(varsIEQM.keys())[0]]['type']
                            long_champ = ""
                            if type_champ.find("DOUBLE PRECISION") != -1:
                                type_champ_ogr = "DOUBLE PRECISION"
                                type_champ_esri = "DOUBLE"
                            elif type_champ.find("VARCHAR_") != -1:
                                long_champ = "("+type_champ.split("_")[1]+")"
                                type_champ_ogr = type_champ.split("_")[0]
                                type_champ_esri = "TEXT"
                            elif type_champ.find("SHORT") != -1:
                                type_champ_ogr = "SMALLINT"
                                type_champ_esri = type_champ

                            if debug:
                                arcpy.AddWarning(cle + " " + type_champ+"("+type_champ_ogr+","+type_champ_esri+")" + " " + long_champ + " sera ajoute")

                            sql_alter = """ogrinfo "%s" -sql "alter table %s add column %s %s%s" """ % (os.path.join(reptrav, gdbname_pivot), tabletransit_gdb, cle, type_champ_ogr, long_champ)
                            # arcpy.AddWarning(sql_alter)
                            execute_ogr(sql_alter)
                            if gdb_version == "9.3":
                                arcpy.AddField_management(dest_table_flat, cle, type_champ_esri, "", "", long_champ.replace("(", "").replace(")", ""), "", "NULLABLE", "NON_REQUIRED", "")
                            elif str(sys.version_info[0])+str(sys.version_info[1]) == "25" and gdb_version == "10":
                                sql_alter = """ogrinfo "%s" -sql "alter table %s add column %s %s%s" """ % (dest_gdb_path, tbl_name, cle, type_champ_ogr, long_champ)
                                execute_ogr(sql_alter)
                            else:
                                arcpy.AddField_management(dest_table_flat, cle, type_champ_esri, "", "", long_champ.replace("(", "").replace(")", ""), "", "NULLABLE", "NON_REQUIRED", "")

                    # /////////////////////////////
                    # CRÉATION DU SQL POUR PIVOT
                    table_sortie = dict_prod['pivot']['nom']

                    di_elem_joindre[table_sortie] = "aj%s" % cnt_rel
                    sql_var = "create table %s as select %s," % (table_sortie, champpk)

                    for vardendro in dict_prod['var']:
                        val_vardendro = list(vardendro.keys())[0]

                        val_vardendro_alias = vardendro[val_vardendro]['alias']
                        coalesced = ""
                        coalescef = ""

                        if val_vardendro == "ETA_ESS_PC" or val_vardendro == "TY_COUV_ET" or val_vardendro == "CL_AGE_ET":
                            for essence in li_var_essence_group_prod:  ### SUP, INF
                                as_var = "%s_%s_%s" % (essence, val_vardendro, produit.upper())
                                as_var = "%s_%s" % (val_vardendro_alias, essence)

                                sql_var += "MAX(case when %s = '%s' then %s end) as '%s'," % ( ### case when ETAGE = 'SUP' then ETA_ESS_PC end) as as_var
                                    dict_prod['pivot']['champpivot'],
                                    essence,
                                    val_vardendro,
                                    as_var)

                        else:
                            if val_vardendro in li_coalesce:
                                coalesced = "COALESCE("
                                coalescef = ",0.0)"

                            for essence in li_var_essence_group_prod:
                                as_var = "%s_%s_%s" % (essence, val_vardendro, produit.upper())
                                as_var = "%s_%s" % (val_vardendro_alias, essence)

                                sql_var += "%sCAST(max(case when %s = '%s' then %s end) as %s)%s as '%s'," % (
                                    coalesced,
                                    dict_prod['pivot']['champpivot'],
                                    essence,
                                    val_vardendro,
                                    val_vardendro,
                                    coalescef,
                                    as_var)

                    sql_final = sql_var[:-1]
                    sql_final += " from %s group by %s " % (dict_prod['relat']['nom'], champpk)

                    if debug:
                        arcpy.AddMessage(sql_final)

                    executesql('DROP table IF EXISTS %s' % table_sortie)

                    if executesql(sql_final.replace("DOUBLE PRECISION", "DOUBLE")) is True:
                        arcpy.AddMessage("\n     Succes")
                    else:
                        arcpy.AddError("     Echec du traitement pour cette table.")

                    executesql("CREATE UNIQUE INDEX ndx_PK_%s on %s (%s)" % (cnt_rel, table_sortie, champpk))
                    cnt_rel += 1
                    li_succes_traitements.append(produit)

        # //////////////////////////////
        # Une fois la gestion des pivot, jointure sous SQLITE.
        if debug:
            arcpy.AddWarning(li_succes_traitements)

        arcpy.AddMessage(" ")
        arcpy.AddMessage(" ")
        arcpy.AddMessage("======================================================")
        arcpy.AddMessage("Traitement de la table finale")
        arcpy.AddMessage("======================================================")

        if len(li_succes_traitements) > 0:
            alias_1erjoin = "left_table"
            str_sel = "CREATE TABLE join_tous as SELECT %s.%s as %s, " % (alias_1erjoin, champpk, pk_flat)
            str_from = " from tbl_li_pk as %s " % alias_1erjoin
            for cle, alias in list(di_elem_joindre.items()):
                str_sel += "%s.*," % alias
                str_from += "LEFT OUTER JOIN %s as %s on  %s.%s = %s.%s " % (cle, alias, alias_1erjoin, champpk, alias, champpk)
            str_sql_final = "%s %s" % (str_sel[:-1], str_from)

            arcpy.AddMessage("     Creation de la table finale")
            executesql(str_sql_final)
            arcpy.AddMessage("     Exportation de la table finale vers %s" % dest_table_flat)

            if gdb_version == '9.3':

                cmd_j_tous = load2ogr_tblfinale("FileGDB", reptrav, gdbname_pivot_sansext, pathspatialite, 'join_tous', None, 'table', None, 'append')

                if debug:
                    arcpy.AddMessage(cmd_j_tous)
                lancement_cmd(cmd_j_tous)

                if str(sys.version_info[0])+str(sys.version_info[1]) == "25":
                    if debug:
                        arcpy.AddError("Vous traitez la donnee sous ArcGIS 9.3. A ce jour, Les fonctionnalites d'exportation du traitement vers une Geodatabase (.gdb) d'ESRI compatible avec cette version. Nous procedons avec un curseur d'insertion. ")

                    di_ch, li_ordre_champs = dict_from_nom_chams_sqlite(pathspatialite, "join_tous")

                    li_champs_dest_obj = arcpy.ListFields(dest_table_flat)
                    li_champs_dest = list()
                    di_champs_dest = dict()
                    for champs in li_champs_dest_obj:
                        li_champs_dest.append(champs.name)
                        di_champs_dest[champs.name] = champs.type

                    insert_rows = arcpy.InsertCursor(dest_table_flat)

                    try:
                        li_update_cursor = list()

                        con = lite.connect(pathspatialite)
                        con.row_factory = lite.Row  # IMPORTANT POUR CRÉER LISTE
                        cur = con.cursor()
                        cur.execute('select * from %s;' % tabletransit_gdb)
                        rows_jt = cur.fetchall()

                        for ligne_jt in rows_jt:
                            di_ch_bcl_for = dict(di_ch)
                            cnt = 0
                            for field in li_ordre_champs:

                                di_ch_bcl_for[field] = ligne_jt[cnt]
                                cnt += 1
                            li_update_cursor.append(di_ch_bcl_for)

                        del ligne_jt, rows_jt
                        cnt = 0
                        while cnt < len(li_update_cursor):
                            irow = insert_rows.NewRow()
                            di_courant = li_update_cursor[cnt]
                            if debug:
                                arcpy.AddWarning(str(di_courant))
                            for champs_dest in list(di_champs_dest.keys()):

                                if di_champs_dest[champs_dest] in ('String'):
                                    sep = "'"
                                else:
                                    sep = ""
                                if di_champs_dest[champs_dest] != "OID":
                                    if di_courant[champs_dest] is not None:
                                        cmd = "irow."+champs_dest + "="+sep+str(di_courant[champs_dest])+sep
                                        exec(cmd)
                                        if debug:
                                            arcpy.AddWarning(cmd)

                                else:
                                    cmd = "irow.OBJECTID=" + str(cnt+1)

                            insert_rows.InsertRow(irow)
                            cnt += 1

                    except:
                        import gc
                        gc.collect()
                        import traceback
                        msg = traceback.format_exc()
                        arcpy.AddError(msg)

                    finally:
                        if con:
                            con.close()

                else:
                    if arcpy.Exists(dest_table_flat_transit):
                        arcpy.Append_management(dest_table_flat_transit, dest_table_flat, "No_TEST")
                    else:
                        arcpy.Copy_management(dest_table_flat_transit, dest_table_flat)

            elif gdb_version == '10':

                path_vers_gdb = os.path.dirname(dest_gdb_path)
                gdb_name = os.path.basename(dest_gdb_path)
                gdb_name_sansext = gdb_name.lower().split(".gdb")[0]

                cmd_j_tous = load2ogr_tblfinale("FileGDB", path_vers_gdb, gdb_name_sansext, pathspatialite, 'join_tous', tbl_name, 'table', None, 'append')

                if debug:
                    arcpy.AddMessage(cmd_j_tous)
                lancement_cmd(cmd_j_tous)

            arcpy.AddIndex_management(dest_table_flat, pk_flat, pk_flat)


            ### JOINT DE LA TABLE DE PIVOT FINALE AVEC LA CLASSE D'ENTITES ORIGINALE COPIEE AU MEME ENDROIT
            if ce_join_1.lower().find(".gdb") != -1:
                arcpy.AddMessage(" ")
                arcpy.AddMessage(" ")
                arcpy.AddMessage("======================================================")
                arcpy.AddMessage("Joint de la table avec la couche des peuplements")
                arcpy.AddMessage("======================================================")

                fields = arcpy.ListFields(tbl_joint_gdb)
                fields_to_del = []
                for field in fields:
                    if field.name not in champs_export and field.name not in ('GEOCODE','GEOC_MAJ','Shape','OBJECTID','Shape_Area','Shape_Length'):
                        fields_to_del.append(field.name)

                if len(fields_to_del) != 0:
                    arcpy.DeleteField_management(tbl_joint_gdb, fields_to_del)

                arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), dest_table_flat, "{}".format(nom_geoc), "")
                arcpy.Delete_management(dest_table_flat)

                ### Suppression des champs GEOCODE_123456.... ### 20240601
                fields_to_del2 = []
                fields2 = arcpy.ListFields(tbl_joint_gdb)
                for field in fields2:
                    if field.name[:8] == "GEOCODE_" or field.name[:9] == "GEOC_MAJ_":
                        fields_to_del2.append(field.name)

                if len(fields_to_del2) != 0:
                    arcpy.DeleteField_management(tbl_joint_gdb, fields_to_del2)


                if len(table_meta) + len(table_climat) + len(table_contraintes) + len(table_stations) + len(table_classi_eco) + len(table_biomasse) > 0 and len(champs_autres) > 0:
                    arcpy.AddMessage(" ")
                    arcpy.AddMessage(" ")
                    arcpy.AddMessage("======================================================")
                    arcpy.AddMessage("Joint des champs des tables METADONNEES, CLIMAT, CONTRAINTES, STATIONS, CLASSI_ECO et BIOMASSE")
                    arcpy.AddMessage("======================================================")

                    if len(table_meta) > 0:
                        arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), table_meta, "{}".format(nom_geoc), champs_autres)

                    if len(table_climat) > 0:
                        arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), table_climat, "{}".format(nom_geoc), champs_autres)

                    if len(table_contraintes) > 0:
                        arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), table_contraintes, "{}".format(nom_geoc), champs_autres)

                    if len(table_stations) > 0:
                        arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), table_stations, "{}".format(nom_geoc), champs_autres)

                    if len(table_classi_eco) > 0:
                        arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), table_classi_eco, "{}".format(nom_geoc), champs_autres)

                    if len(table_biomasse) > 0:
                        arcpy.JoinField_management(tbl_joint_gdb, "{}".format(nom_geoc), table_biomasse, "{}".format(nom_geoc), champs_autres)

        else:
            arcpy.AddError("     Aucune table ne sera generee car aucun produit n'a ete traite avec succes.")
            arcpy.AddMessage(" ")
            arcpy.AddMessage(" ")
            arcpy.Delete_management(dest_table_flat)

    except:
        import gc
        gc.collect()
        import traceback
        msg = traceback.format_exc()
        arcpy.AddError(msg)

        try:
            arcpy.Delete_management(dest_table_flat)
        except:
            pass

    finally:
        if debug is False:
            shutil.rmtree(reptrav, ignore_errors=True)


if __name__ == '__main__':

    main()

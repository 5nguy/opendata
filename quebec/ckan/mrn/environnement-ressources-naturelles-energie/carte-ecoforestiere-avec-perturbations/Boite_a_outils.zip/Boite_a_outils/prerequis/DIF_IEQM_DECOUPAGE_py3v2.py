﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Louis-Pierre Couillard
Direction des inventaires forestiers
Courriel: louis-pierre.couillard@mrnf.gouv.qc.ca
"""

# Historique:
# 20240401 Gestion de la table biomasse et carbone (Aucune modification requise)
# 20230323 Retrait de la version en 9.3
# 20210813 Ajout d'un repair geometry ogc a dest_tbl_fc (couche pee_ori/maj decoupee)
# 20210517 Conversion en GPKG
# 20190801 Adaptation pour ArcGIS PRO
# 20160408 Modification pour gestion des noms de geocodes differents.
# 20160303 Modifications pour la performance/stabilite de l'outil.
# 20150827 Gestion de la table cl_dhp.

# -------------------------------------------------------------------------------

import os
import sys
import csv
from random import choice
import random
import string
from random import randrange
import time
import shutil
import arcpy

### FICHIER PTH
user_externe = True
if os.path.exists(r"\\Sef1271a\F1271g\OutilsProdDIF"):
    user_externe = False

    try:
        sys.path.append(r"\\Sef1271a\F1271g\OutilsProdDIF\modules_communs\python27\GestionDossierFichier\bin")
        from GestionDossierFichier import deployer_fichier_pth_VersionExe

        try:
            deployer_fichier_pth_VersionExe("C:/Program Files/ArcGIS/Pro/bin/Python/envs/arcgispro-py3", "G:/OutilsProdDIF/modules_communs/python27", "modules_communs", ['bin'])
        except:
            try:
                deployer_fichier_pth_VersionExe("C:/Mrnmicro/Applic/python27/ArcGIS10.3", "G:/OutilsProdDIF/modules_communs/python27", "modules_communs", ['bin'])
            except:
                try:
                    deployer_fichier_pth_VersionExe("C:/logiciels/Python27/ArcGIS10.3", "G:/OutilsProdDIF/modules_communs/python27", "modules_communs", ['bin'])
                except:
                    pass

        from class_convertIEQM import *
        from class_convertGPKG import *

    except:
        pass
        user_externe = True


def printit(instring):
    arcpy.AddMessage(instring)

def printwarning(instring):
    arcpy.AddWarning(instring)

def printerr(instring):
    arcpy.AddError(instring)


def FcreationEnvTravail(path, alea=None, nom=None):
    """Permet de creer un environnement de travail de type GDB au format ArcGIS que vous utilisez.
    Les parametres possible sont les suivants:
        Path: repertoire de travail
        alea: creer un nom aleatoire (True/False), Si un nom est present, l'aspect aleatoire n'est pas evalue.
        Nom: nom de la MDB, doit comporter l'extension dans le nom.

        Le chemin de la MDB cree est retourne par la fonction et l'environnement de travail (workspace lui est assigne)

     gdbPath = FcreationEnvTravail(reptrav,True,"NOM.MDB")
    """
    if alea:
        nom = 'gdb_temporaire_%s_%s_%s.gdb' % (randrange(100000000), randrange(100000000), randrange(100000000))
    else:
        if nom is None:
            nom = 'gdb_temporaire.gdb'

    fpath = os.path.join(path, nom)
    # Creation de la gdb temporaire de traitement.
    if arcpy.Exists(fpath):
        pass
    else:
        arcpy.CreateFileGDB_management(path, nom, '10.0') #### Mars 2023 remove version 9.3

    return fpath


def FlistFieldNames(elem):
    nomchamps = [champs.name for champs in arcpy.ListFields(elem)]

    nomchampsLower = []
    nomchampsUpper = []
    for nomchamp in nomchamps:
        nomchampsLower.append(nomchamp.lower())
    for nomchamp in nomchamps:
        nomchampsUpper.append(nomchamp.upper())

    return nomchamps, nomchampsLower, nomchampsUpper


def fgestionsuppression(elem):
    try:
        if arcpy.Exists(elem):
            arcpy.Delete_management(elem)
        else:
            pass
    except:
        pass

def gestionGeom(ce, typeDonnee, ce_Decoupe, option_buffer, gdb_sortie, nomSortie, nomliaison):
    import arcpy
    lyr1 = 'lyr1_%s_%s_%s' % (randrange(100000000), randrange(100000000), randrange(100000000))  # Creation du layer files pour la carte originale
    arcpy.MakeFeatureLayer_management(ce, lyr1)

    arcpy.SelectLayerByLocation_management(lyr1, 'intersect', ce_Decoupe, option_buffer)
    count = arcpy.GetCount_management(lyr1)
    arcpy.AddMessage(count[0] + ' polygones intersectes')

    if count == 0:
        error = "La zone selectionnee ne comporte aucun element (%s). " % (typeDonnee)
        printerr(error)
        cout = None
        try:
            import arcpy
            arcpy.Delete_management(lyr1)
        except:
            fgestionsuppression(lyr1)

        del lyr1
        return cout

    if not arcpy.Exists(os.path.join(gdb_sortie, nomSortie)):
        arcpy.FeatureClassToFeatureClass_conversion(lyr1, gdb_sortie, nomSortie)
    else:
        printwarning("La table ou la classe d'entite nommee %s existe deja dans la GDB de destination. \nElle ne sera pas ecrasee." % nomSortie)

    cout = os.path.join(gdb_sortie, nomSortie)
    try:
        arcpy.AddSpatialIndex_management(cout)
    except:
        pass
    try:
        fcheckindex(cout, nomliaison, nomliaison, 0, True, False)
    except:
        pass

    try:
        import arcpy
        arcpy.Delete_management(lyr1)
    except:
        fgestionsuppression(lyr1)

    del lyr1
    return cout


def unique_values(table, field):
    with arcpy.da.SearchCursor(table, [field]) as se_cursor:
        li = []
        for row in se_cursor:
            if row[0] not in li:
                li.append(row[0])
        del row
    del se_cursor
    return li


def fcheckindex(fichier, champ, nomindex_perso, pos, unique=False, verbose=False):
    try:
        if not nomindex_perso.lower() in [nomindex.name.lower() for nomindex in arcpy.ListIndexes(fichier)]:
            msg = "\nCreation d'un index sur le champ %s de la table %s" % (champ, fichier)
            if fichier.lower().find("dbf") != -1:
                pass
            else:
                if not verbose == False:
                    printwarning(msg)
                if unique is False:
                    arcpy.AddIndex_management(fichier, champ, nomindex_perso)
                else:
                    arcpy.AddIndex_management(fichier, champ, nomindex_perso, "UNIQUE")
    except:
        printwarning("Echec de la creation de l'index sur le champ %s de la donnee %s" % (champ, fichier))
        pass


def csvtodict(chemincsv, nom1erchamp='nom'):
    """
    Auteur: Pierre-Etienne Lord
    Date creation : 2016-04-12
    Cette fonction permet de convertir un fichier CSV en dictionnaire python.
    Fonctionne avec python 2.6 + et permet de gerer si votre separateur de champ est un ";".
    Automatiquement, il fait la gestion de ";" vers "," vers un repertoire temporaire..

    Args:
        chemincsv (str): Parametre de chemin d'acces du fichier csv a convertir.
        nom1erchamp (str): nom du premier champ qui sert de clef pour chacune ces lignes du csv.
    Returns:
        di_return (dict): Le dictionnaire retourne avec le contenu du CSV transpose.

    exemple d'Appel: di_nom_produits_ieqm = csvtodict("\\path\vers\csv.csv,'nomdupremierchamp')
    """

    di_return = dict()
    reader = ""
    try:
        reader = csv.DictReader(open(chemincsv))
        di_return = {}
        for row in reader:
            key = row.pop(nom1erchamp)
            if key in di_return:
                # implement your duplicate row handling here
                pass
            di_return[key] = row
        del reader
    except KeyError:
        del reader
        from tempfile import mkdtemp
        from shutil import rmtree

        temp_dir = mkdtemp()

        nouv = "%s\%s.tmp" % (temp_dir, os.path.basename(chemincsv))
        f1 = open(chemincsv, 'r')
        f2 = open(nouv, 'w')
        for line in f1:
            f2.write(line.replace(';', ','))
        f1.close()
        f2.close()
        di_return = csvtodict(nouv, nom1erchamp)
        rmtree(temp_dir)

    return di_return


def fcreerlyr(ce, clause=None):
    from random import randrange
    import time

    localtime = time.localtime()
    timestring = time.strftime("%Y%m%d_%Hh%Mm%Ssec", localtime)
    lyr = 'lyr_%s_%s' % (timestring, randrange(100000000))

    if clause is not None:
        arcpy.MakeFeatureLayer_management(ce, lyr, clause)
    else:
        arcpy.MakeFeatureLayer_management(ce, lyr)
    return lyr


def main():
    """
    Module principal permettant de faire la preparation de la donnees.
    """

    global li_elem_supprimer, debug
    li_elem_supprimer = []
    debug = False

    try:
        ## Obligatoire
        reptrav = arcpy.GetParameterAsText(0)
        ce_geomsource = arcpy.GetParameterAsText(1)
        ce_geommetado = arcpy.GetParameterAsText(2)
        str_li_attrib_relationnel = arcpy.GetParameterAsText(3)

        # Facultatif
        ce_geomselection = arcpy.GetParameterAsText(4)  # Entite permettant de faire une decoupe. N'est pas necessaire
        option_champsmulti = arcpy.GetParameterAsText(5)
        option_buffer = arcpy.GetParameterAsText(6)  # Option de buffer. Est a 0 par defaut
        str_li_attrib_copie = arcpy.GetParameterAsText(7)

        #### DETERMINER SI L'OUTIL EST UTILISE A L'INTERNE DANS LE CONTEXTE UA DIF OU NON ############################################

        contexte_decoupe_dif_coad = arcpy.GetParameterAsText(8)  ### Si vrai, c'est un contexte de decoupe UA et le champ servant de suffixe a la gdb doit etre NO_PER_UA, AGENCE, etc..

        ### CONSTANTES
        if "PEE_MAJ" in ce_geomsource:
            contexte = "MAJ"
            chemincsv = os.path.join(os.path.dirname(sys.argv[0]), "StructureIEQM_caj.csv")
            arcpy.AddMessage(chemincsv)
        else:
            contexte = "ORI"
            chemincsv = os.path.join(os.path.dirname(sys.argv[0]), "StructureIEQM.csv")
            arcpy.AddMessage(chemincsv)

        di_nom_produits_ieqm = csvtodict(chemincsv)
        li_poss_geoc = list()

        for cle, valeur in list(di_nom_produits_ieqm.items()):
            for val in list(valeur.keys()):
                if valeur["nom_liaison"] not in li_poss_geoc:
                    li_poss_geoc.append(valeur["nom_liaison"])

        if str_li_attrib_relationnel is not None:
            li_attrib_relationnel = str_li_attrib_relationnel.split(";")
        else:
            li_attrib_relationnel = None

        # S'assurer qu'il n'y a pas de doublons geometriques et attributaire.

        if int(str(arcpy.GetCount_management(ce_geomselection))) > 1 and option_champsmulti == "":
            shutil.rmtree(reptrav)
            error = "La geometrie de traitemement selectionnee comporte plusieurs geometries\n et vous n'avez pas selectionne de champs les distinguant dans l'interface.\n\n Veuillez selectionner un champ distinguant les geometries dans l'interface de l'outil.\n"
            printerr(error)
            sys.exit()

        # option_champsmulti = 'FCA_NO_DECOU_250K'
        nb_geom_distincte = int(str(arcpy.GetCount_management(ce_geomselection)))

        if option_champsmulti != "":
            if arcpy.Exists("in_memory\ce_geomselection_diss"):
                fgestionsuppression("in_memory\ce_geomselection_diss")

            with arcpy.da.SearchCursor (ce_geomselection, [option_champsmulti]) as se_cursor:
                li_valeurs_bcl = []
                for row in se_cursor:
                    a = row[0]
                    if a not in li_valeurs_bcl:
                        li_valeurs_bcl.append(a)
                del row
            del se_cursor

            if nb_geom_distincte != len(li_valeurs_bcl):
                printwarning("Selon la geometrie de decoupe fournie et le champ fourni (%s), vous avez un nombre different de geometries distinctes. Un dissolve sera effectue sur l'entite de decoupe pour resoudre cette problematique." % option_champsmulti)
                arcpy.Dissolve_management(ce_geomselection, "in_memory\ce_geomselection_diss", option_champsmulti)
            else:
                arcpy.CopyFeatures_management(ce_geomselection, "in_memory\ce_geomselection_diss")
            ce_geomselection = "in_memory\ce_geomselection_diss"

            li_val_distinctes = unique_values(ce_geomselection, option_champsmulti)

            champ_a_supprimer_decoupe = None
            if contexte_decoupe_dif_coad == 'true':
                champ_a_supprimer_decoupe = "decoupe_dif"
                arcpy.AddField_management(ce_geomselection, champ_a_supprimer_decoupe, "TEXT", "#", "#", "50")

                if option_champsmulti == 'NO_TERRI':
                    champs = [option_champsmulti, champ_a_supprimer_decoupe, "NO_TDA"]
                else:
                    champs = [option_champsmulti, champ_a_supprimer_decoupe]

                with arcpy.da.UpdateCursor (ce_geomselection, champs) as up_cursor:

                    for row in up_cursor:

                        if option_champsmulti in ('NO_PER_UA', 'PER_NO_UA'):
                            row[1] = contexte + '_UA_' + row[0]
                            up_cursor.updateRow(row)

                        elif option_champsmulti == 'NO_AGENCE':
                            row[1] = contexte + '_A' + row[0]
                            up_cursor.updateRow(row)

                        elif option_champsmulti == 'NO_TDA':
                            row[1] = contexte + '_TFR_' + row[0]
                            up_cursor.updateRow(row)

                        elif option_champsmulti == 'NO_TERRI':
                            if row[0][0] == 'A':
                                row[1] = contexte + '_' + row[0]
                                up_cursor.updateRow(row)
                            else:
                                row[1] = contexte + '_UA_' + row[0]
                                up_cursor.updateRow(row)

                            if row[2] == '096001':
                                row[1] = contexte + '_TFR_' + row[0]
                                up_cursor.updateRow(row)

                        elif option_champsmulti == "IDX_NO_DEC":
                            row[1] = contexte + '_' + row[0]
                            up_cursor.updateRow(row)

                    li_val_distinctes = unique_values(ce_geomselection, champ_a_supprimer_decoupe)

                    del row
                del up_cursor


        nb_gdb_crees = int(str(arcpy.GetCount_management(ce_geomselection)))
        option_buffer = str(option_buffer) + " meters"

        if str_li_attrib_copie not in (None, '', "", "#"):
            li_attrib_copie = str_li_attrib_copie.split(";")
        else:
            li_attrib_copie = None

        msg = "\n#====================================="
        msg += "\n# PARAMETRES=========================="
        msg += "\n#=====================================\n"
        printit(msg)

        printit("A-L'environnement de travail pour les extrants sera: %s" % reptrav)
        if nb_gdb_crees == 1:
            printit("Dans ce repertoire, les donnees IEQM seront reunies vers la gdb Produits_IEQM.gdb")
            di_gdb_crees = {"Type": "IndexSeul", "nom_gdb_crees": ["Produits_IEQM.gdb"]}
        else:
            printwarning("Selon la structure de l'entite de traitement selectionnee:")
            printit("Dans ce repertoire, il y aura %s gdbs creees:" % nb_gdb_crees)
            di_gdb_crees = {"Type": "IndexMulti", "nom_gdb_crees": []}
            li_tmp = []
            cnt_print_nom_gdb = 0
            for val_distinctes in li_val_distinctes:
                if cnt_print_nom_gdb < 10:
                    printit("PRODUITS_IEQM_%s.gdb" % val_distinctes)
                elif cnt_print_nom_gdb == 10:
                    printit("...")
                else:
                    pass
                li_tmp.append("PRODUITS_IEQM_%s.gdb" % val_distinctes)
                cnt_print_nom_gdb +=1

            di_gdb_crees["nom_gdb_crees"] = li_tmp
            del li_tmp

        printit("B-Les intrants relationnels de la DIF traites seront les suivants:")

        di_traitement_ieqm = dict()
        li_source = list()
        if ce_geomsource.lower()[-5:] == "_prov":
            trim_parent = ce_geomsource[:-5]
        else:
            trim_parent = ce_geomsource

        for cle, valeur in list(di_nom_produits_ieqm.items()):
            if valeur['modelerelationnel'] == 'parent':
                if valeur['nom_physique'].lower() in ce_geomsource.lower():
                    di_traitement_ieqm['PARENT'] = {"nom_liaison": valeur['nom_liaison'], 'type': valeur['type'], "intrant": ce_geomsource, "extrant": os.path.basename(trim_parent)}
                    del di_nom_produits_ieqm[cle]
                    break

        if len(di_traitement_ieqm) == 0:
            printerr("L'appellation de la geometrie source ne semble pas etre une appellation de produit IEQM")
            sys.exit("L'appellation de la geometrie source ne semble pas etre une appellation de produit IEQM")

        if ce_geommetado.lower()[-5:] == "_prov":
            trim = ce_geommetado[:-5]
        else:
            trim = ce_geommetado

        li_source.append(os.path.dirname(ce_geommetado))
        for cle, valeur in list(di_nom_produits_ieqm.items()):
            if valeur['modelerelationnel'] != 'parent':
                if valeur['nom_physique'].lower() in ce_geommetado.lower():
                    di_traitement_ieqm['Metadonnees'] = {"nom_liaison": valeur['nom_liaison'], 'type': valeur['type'], 'relation': valeur['relation'], "intrant": ce_geommetado, "extrant": os.path.basename(trim), "nom_cl_relation": valeur['nom_cl_relation']}
                    break

        if len(di_traitement_ieqm) <= 1:
            printerr("L'appellation des metadonnees ne semble pas être une appellation de produit IEQM")
            sys.exit("L'appellation des metadonnees ne semble pas être une appellation de produit IEQM")

        if li_attrib_relationnel is not None:
            for attrib_relationnel in li_attrib_relationnel:
                print (attrib_relationnel)
                attrib_relationnel = attrib_relationnel.replace("'", "")
                table_attrib_relationnel_courant = os.path.basename(attrib_relationnel)
                attrib_relationnel_dirname = os.path.dirname(attrib_relationnel)

                for nom_produits_IEQM, params in list(di_nom_produits_ieqm.items()):
                    if params["nom_physique"] in table_attrib_relationnel_courant:
                        printit(nom_produits_IEQM)
                        if attrib_relationnel_dirname not in li_source:
                            li_source.append(attrib_relationnel_dirname)
                        if table_attrib_relationnel_courant.lower()[:-4] == ".dbf":
                            table_attrib_relationnel_courant = table_attrib_relationnel_courant[:-4]
                        if table_attrib_relationnel_courant.lower()[-5:] == "_prov":
                            trim = table_attrib_relationnel_courant[:-5]
                        else:
                            trim = table_attrib_relationnel_courant
                        if attrib_relationnel == di_traitement_ieqm['PARENT']["intrant"]:
                            continue
                        di_traitement_ieqm[nom_produits_IEQM] = {"nom_liaison": params["nom_liaison"], 'type': params["type"], 'relation': params["relation"], "intrant": attrib_relationnel, "extrant": trim, "nom_cl_relation": params["nom_cl_relation"]}
                        break

        if debug:
            printerr(li_source)
            printerr(str(di_traitement_ieqm))

        printit("C-Validation de la presence d'index sur les champs de liaison (GEOCODE ou GEOC_...) sur les intrants identifies.")

        for nom_ieqm, di_io_ieqm in list(di_traitement_ieqm.items()):
            fcheckindex(di_io_ieqm["intrant"], di_io_ieqm["nom_liaison"], di_io_ieqm["nom_liaison"], 2, False)

        printit("Termine")
        printit("\n")

        if option_champsmulti == "":
            field = ["Shape"]
        else:
            if contexte_decoupe_dif_coad == 'true':
                field = [option_champsmulti, "Shape", champ_a_supprimer_decoupe]
            else:
                field = [option_champsmulti, "Shape"]


        with arcpy.da.SearchCursor (ce_geomselection, field) as se_cursor:
            cnt = 1
            li_elem_supprimer = []

            for row in se_cursor:

                printit("\n")
                msg = "#====================================================================================\n"
                msg += "# Traitement du perimetre %s/%s ===================================================\n" % (cnt, nb_gdb_crees)
                msg += "#====================================================================================\n"
                printit(msg)

                nomPerim = "PERIMETRE_NO_TERRI"

                if di_gdb_crees['Type'] == 'IndexSeul':
                    suffixe = ""
                    suffixe_decoupe = ""

                    gdb_sortie_ieqm = FcreationEnvTravail(reptrav, False, "PRODUITS_IEQM.gdb")
                    if not arcpy.Exists(os.path.join(gdb_sortie_ieqm, nomPerim)):
                        arcpy.FeatureClassToFeatureClass_conversion(ce_geomselection, gdb_sortie_ieqm, nomPerim)

                elif di_gdb_crees['Type'] == 'IndexMulti':
                    if contexte_decoupe_dif_coad == 'true':

                        if option_champsmulti in ('NO_PER_UA', 'PER_NO_UA'):
                            suffixe = row[2]
                            suffixe_decoupe = suffixe[6:]
                            suffixe_query = suffixe[7:]

                        elif option_champsmulti in ('NO_AGENCE'):
                            suffixe = row[2]
                            suffixe_decoupe = '_' + suffixe[5:]
                            suffixe_query = suffixe[5:]

                        elif option_champsmulti in ('NO_TDA'):
                            suffixe = row[2]
                            suffixe_decoupe = suffixe[7:]
                            suffixe_query = suffixe[8:]

                        elif option_champsmulti in ('NO_TERRI'):
                            suffixe = row[2]
                            if 'UA' in suffixe:
                                suffixe_decoupe = suffixe[6:]
                                suffixe_query = suffixe[7:]
                            elif 'TFR' in suffixe:
                                suffixe_decoupe = suffixe[7:]
                                suffixe_query = suffixe[8:]
                            else:
                                suffixe_decoupe = '_' + suffixe[5:]
                                suffixe_query = suffixe[4:]

                        elif option_champsmulti in ('IDX_NO_DEC'):
                            suffixe = row[2]
                            suffixe_decoupe = suffixe[3:]
                            suffixe_query = suffixe[4:]

                    else:
                        suffixe = row[0]
                        suffixe_decoupe = "_" + suffixe
                        suffixe_query = suffixe

                    gdb_sortie_ieqm = FcreationEnvTravail(reptrav, False, "PRODUITS_IEQM_%s.gdb" % (suffixe))

                    nomPerim = "PERIMETRE_NO_TERRI%s" % suffixe_decoupe


                    lyrtmp = 'lyr_%s_%s_%s' % (randrange(100000000), randrange(100000000), randrange(100000000))
                    arcpy.MakeFeatureLayer_management(ce_geomselection, lyrtmp, """"%s" = '%s'""" % (option_champsmulti, suffixe_query))
                    if not arcpy.Exists(os.path.join(gdb_sortie_ieqm, nomPerim)):
                        arcpy.FeatureClassToFeatureClass_conversion(lyrtmp, gdb_sortie_ieqm, nomPerim)
                    fgestionsuppression(lyrtmp)

                if contexte_decoupe_dif_coad == 'true':
                    arcpy.DeleteField_management(os.path.join(gdb_sortie_ieqm, nomPerim), "decoupe_dif")

                ce_geomselectioncourant = os.path.join(gdb_sortie_ieqm, nomPerim)


                printit("Les donnees seront exportees vers:")
                printit(gdb_sortie_ieqm)
                printit("\n")

                # ====================
                #  CARTE ORIGINALE
                # ====================

                printit("GESTION DE LA GEOMETRIE SOURCE")
                printit("Selection du contenu de la geometrie source pour le perimetre identifie.")
                cout_geomsrc = gestionGeom(di_traitement_ieqm['PARENT']['intrant'], "geometrie source", ce_geomselectioncourant, option_buffer, gdb_sortie_ieqm, di_traitement_ieqm['PARENT']['extrant'] + suffixe_decoupe, di_traitement_ieqm['PARENT']['nom_liaison'])

                li_geom_src = "li_geom_src_%s" % randrange(100000000)
                if cout_geomsrc is None:
                    error = "L'entite de traitement ne contient pas de geometrie source. On poursuit donc vers le prochain element. \n"
                    # shutil.rmtree(gdb_sortie_ieqm)
                    printerr(error)
                    cnt += 1
                    continue

                else:
                    if debug:
                        printwarning(str(li_elem_supprimer))
                    for gdb_distante in li_source:

                        dest_geom_src_tmp = os.path.join(gdb_distante, li_geom_src)
                        if debug:
                            printwarning(dest_geom_src_tmp)

                        if not arcpy.Exists(dest_geom_src_tmp):
                            arcpy.TableToTable_conversion(cout_geomsrc, gdb_distante, li_geom_src)
                            fcheckindex(os.path.join(gdb_distante, li_geom_src), di_traitement_ieqm['PARENT']['nom_liaison'], di_traitement_ieqm['PARENT']['nom_liaison'], 0, False, False)
                            li_elem_supprimer.append(os.path.join(gdb_distante, li_geom_src))

                if debug:
                    printwarning(str(li_elem_supprimer))

                # ====================
                #  AUTRES PRODUITS IEQM
                # ====================

                parent = di_traitement_ieqm["PARENT"]['extrant'] + suffixe_decoupe
                for clef, valeur in list(di_traitement_ieqm.items()):
                    if clef not in 'PARENT':
                        printit("\n")
                        printit("GESTION %s" % (clef.upper()))

                        lyr = 'lyr_%s' % (randrange(100000000))

                        where_clause = "%s in (select %s from %s)" % (valeur['nom_liaison'], valeur['nom_liaison'], li_geom_src)
                        dest_tbl_fc = os.path.join(gdb_sortie_ieqm, valeur['extrant'] + suffixe_decoupe)


                        if valeur['type'] in 'geometry':
                            arcpy.MakeFeatureLayer_management(valeur['intrant'], lyr, where_clause)
                        else:
                            arcpy.MakeTableView_management(valeur['intrant'], lyr, where_clause)

                        countlyr = int(str(arcpy.GetCount_management(lyr)))
                        if countlyr > 0:
                            if not arcpy.Exists(os.path.join(gdb_sortie_ieqm, valeur['extrant'] + suffixe_decoupe)):
                                if valeur['type'] in 'geometry':
                                    arcpy.CopyFeatures_management(lyr, dest_tbl_fc)
                                    try: ### Dans arcmap ne passe pas (argument OGC seulement en PRO)
                                        arcpy.RepairGeometry_management(dest_tbl_fc, "", "OGC")
                                    except:
                                        pass
                                else:
                                    arcpy.TableToTable_conversion(lyr, gdb_sortie_ieqm, valeur['extrant'] + suffixe_decoupe)

                                fcheckindex(dest_tbl_fc, valeur['nom_liaison'], valeur['nom_liaison'], 0, True, False)
                            else:
                                printwarning("La table ou la classe d'entitee nommee %s existe deja dans la GDB de destination. \nElle ne sera pas ecrasee." % (valeur['extrant'] + suffixe_decoupe))
                            if not arcpy.Exists(os.path.join(gdb_sortie_ieqm, valeur['nom_cl_relation'])):
                                try:
                                    arcpy.CreateRelationshipClass_management(
                                        os.path.join(gdb_sortie_ieqm, parent),
                                        dest_tbl_fc,
                                        os.path.join(gdb_sortie_ieqm, valeur['nom_cl_relation']),
                                        "SIMPLE",
                                        " ",
                                        " ",
                                        "NONE",
                                        valeur['relation'],
                                        "NONE",
                                        valeur['nom_liaison'],
                                        valeur['nom_liaison'],
                                        "#")
                                except:
                                    pass
                            else:
                                printwarning("La classe de relation nommee %s existe deja dans la GDB de destination. \nElle ne sera pas ecrasee." % (valeur['nom_cl_relation']))
                        else:
                            printwarning("La zone selectionnee ne comporte aucun element. ")

                        fgestionsuppression(lyr)

                        printit("Termine")

                if li_elem_supprimer:
                    for elem in li_elem_supprimer:
                        fgestionsuppression(elem)  # arcpy.Delete_management(elem)
                cnt += 1

                # ====================
                #  PRODUITS A COPIER SEULEMENT
                # ====================

                printit("\n")
                printit("GESTION DES ELEMENTS A COPIER VERS LA DESTINATION DE SORTIE")
                if li_attrib_copie != None:
                    indicateurGeom = None
                    for attrib_copie in li_attrib_copie:
                        ori_attrib_copie = attrib_copie
                        attrib_copie = attrib_copie.lower()

                        if attrib_copie.find(".shp") != -1:
                            nomsortie = os.path.basename(ori_attrib_copie)[:-4]
                            indicateurGeom = True
                        elif attrib_copie.find(".dbf") != -1:
                            nomsortie = os.path.basename(ori_attrib_copie)[:-4]
                            indicateurGeom = False
                        else:
                            if attrib_copie.lower().find(".gdb") != -1 or attrib_copie.find(".mdb") != -1:
                                nomsortie = os.path.basename(ori_attrib_copie)
                                if arcpy.Describe(ori_attrib_copie).DataType == 'FeatureClass':
                                    indicateurGeom = True
                                elif arcpy.Describe(ori_attrib_copie).DataType == 'Table':
                                    indicateurGeom = False

                        if indicateurGeom != None:
                            if arcpy.Exists(os.path.join(gdb_sortie_ieqm, nomsortie)):
                                nomsortieori = nomsortie
                                cnt_itera = 0
                                while arcpy.Exists(os.path.join(gdb_sortie_ieqm, nomsortie)):
                                    cnt_itera += 1
                                    nomsortie = "%s_%s" % (nomsortieori, cnt_itera)
                            printit("Copie de %s vers %s/%s" % (ori_attrib_copie, gdb_sortie_ieqm, nomsortie))
                            if indicateurGeom == True:
                                arcpy.FeatureClassToFeatureClass_conversion(ori_attrib_copie, gdb_sortie_ieqm, nomsortie)
                            elif indicateurGeom == False:
                                arcpy.TableToTable_conversion(ori_attrib_copie, gdb_sortie_ieqm, nomsortie)

                            if contexte_decoupe_dif_coad == 'true' and nomsortie.upper() == 'META_CMP_ORI_PROV':

                                arcpy.MakeTableView_management(os.path.join(gdb_sortie_ieqm, nomsortie), "tmp")

                                query = """"%s" <> '%s'""" % (option_champsmulti, suffixe_query)
                                arcpy.SelectLayerByAttribute_management("tmp", "NEW_SELECTION", query)
                                arcpy.DeleteRows_management('tmp')
                                fgestionsuppression('tmp')
                                if int(str(arcpy.GetCount_management(os.path.join(gdb_sortie_ieqm, nomsortie)))) == 0:
                                    printwarning("Le contenu de la table META_CMP pour cette decoupe en UA n'existe pas. La table sera supprimee.")
                                    fgestionsuppression(os.path.join(gdb_sortie_ieqm, nomsortie))
                                else:
                                    arcpy.Rename_management(os.path.join(gdb_sortie_ieqm, nomsortie), (os.path.join(gdb_sortie_ieqm, nomsortie).upper().replace("PROV",suffixe_query)))

                    printit("\n")
                else:
                    printit("Aucun element a copier.")


                if contexte_decoupe_dif_coad == 'false' or option_champsmulti in ('IDX_NO_DEC'):

                    gdb_sortie_ieqm_v10 = gdb_sortie_ieqm[:-4] + "_10" + gdb_sortie_ieqm[-4:]
                    arcpy.Rename_management(gdb_sortie_ieqm, gdb_sortie_ieqm_v10)
                    #arcpy.UpgradeGDB_management(gdb_sortie_ieqm_v10)

                    arcpy.Compact_management(gdb_sortie_ieqm_v10)


                    if os.path.exists(r"\\Sef1271a\F1271g\OutilsProdDIF") and user_externe == False:

                        arcpy.AddMessage('Création du Geopackage..')

                        if "PEE_ORI_PROV" in ce_geomsource: ### Decoupe d'un produit ori_prov

                            nb_caract_enlever = 4
                            if gdb_sortie_ieqm[-7] == "_":
                                nb_caract_enlever = 3

                            gdb = gdb_sortie_ieqm_v10
                            nom_gpkg = os.path.basename(gdb)[:-7]

                            objConvertIeqm = ConvertIEQM(gdbAConvert=gdb,
                                                         gpkgNomSortie=nom_gpkg + ".gpkg",
                                                         pathGpkgStyle="G:/OutilsProdDIF/modules_communs/python27/conversionFormat/prerequis/ieqm_styles.gpkg",
                                                         pathGpkgCode="",
                                                         pathGdal="G:/OutilsProdDIF/modules_communs/gdal/gdal2.3.2",
                                                         nbCaractereAEnleverNomTab=nb_caract_enlever,
                                                         ieqmType="ori")

                            objConvertIeqm.conversion()


                        elif "PEE_ORI" in ce_geomsource: ### Decoupe d'un produit ori deja decoupe

                            gdb_convertir = gdb_sortie_ieqm[:-4]
                            cpt1 = -1
                            while gdb_convertir[cpt1-4:cpt1] != "IEQM":
                                cpt1 -= 1

                            cpt2 = -1
                            while ce_geomsource[cpt2-3:cpt2] != "ORI":
                                cpt2 -= 1

                            nb_caract_enlever = (cpt1 + cpt2) * -1  ### addition des 2 séries de caracts a effacer et ramener nombre en positif
                            arcpy.AddMessage(nb_caract_enlever)

                            gdb = gdb_sortie_ieqm_v10
                            nom_gpkg = os.path.basename(gdb)[:-7]

                            objConvertIeqm = ConvertIEQM(gdbAConvert=gdb,
                                                         gpkgNomSortie=nom_gpkg + ".gpkg",
                                                         pathGpkgStyle="G:/OutilsProdDIF/modules_communs/python27/conversionFormat/prerequis/ieqm_styles.gpkg",
                                                         pathGpkgCode="",
                                                         pathGdal="G:/OutilsProdDIF/modules_communs/gdal/gdal2.3.2",
                                                         nbCaractereAEnleverNomTab=nb_caract_enlever,
                                                         ieqmType="ori")

                            objConvertIeqm.conversion()

                        else: ### Decoupe d'un produit maj (pas de vues relationnelles dans les produits maj, conversion standard)

                            gdb = gdb_sortie_ieqm_v10
                            nom_gpkg = os.path.basename(gdb)[:-7]

                            convertisseur = ConvertisseurGPKG(gdbAConvert=gdb,
                                gpkgNomSortie=nom_gpkg + ".gpkg",
                                pathGpkgStyle="G:/OutilsProdDIF/modules_communs/python27/conversionFormat/prerequis/ieqm_styles.gpkg",
                                pathGdal="G:/OutilsProdDIF/modules_communs/gdal/gdal2.3.2")

                            convertisseur.conversion()


            del row
        del se_cursor

    except:
        import gc
        gc.collect()
        import traceback
        msg = (traceback.format_exc())
        printerr(msg)
        printwarning("Rapportez les problematiques observees a:\n inventaires.forestiers@mffp.gouv.qc.ca. \n\n Copiez le message en rouge ci-dessus pour nous le faire parvenir.\n Merci. \n ")

        if debug is False:
            if li_elem_supprimer != []:
                for elem in li_elem_supprimer:
                    fgestionsuppression(elem)  # arcpy.Delete_management(elem)

# Run the script
if __name__ == '__main__':
    main()

﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-

import arcgisscripting
import os
import arcpy
import sys

"""
Auteur:
Louis-Pierre Couillard
Mai 2019
"""


def transfert(kit_ori, kit_maj):

    pee_maj = ""

    for dirpath, dirnames, filenames in arcpy.da.Walk(kit_maj, datatype="FeatureClass"):

        for filename in filenames:
            if filename.startswith("PEE_MAJ"):
                pee_maj = pee_maj + kit_maj + "/" + filename

    for dirpath, dirnames, filenames in arcpy.da.Walk(kit_ori, datatype="Any"):

        for filename in filenames:
            if filename.startswith("META_ORI") or filename.startswith("META_CMP_ORI") or filename.startswith("DENDRO_PEE_TIGES_DHP_ORI"):

                chemin_ori = kit_ori + "/" + filename
                chemin_maj = kit_maj + "/" + filename

                if not gp.exists(chemin_maj):
                    try:
                        arcpy.CopyFeatures_management(chemin_ori, chemin_maj)
                    except:
                        arcpy.TableToTable_conversion(chemin_ori, kit_maj, "{}".format(filename), "")
                else:
                    gp.AddMessage("L'element %s existe deja dans la GDB %s." % (filename, os.path.basename(kit_maj)))
                    gp.AddMessage(" ")


                if filename.startswith("META_ORI"):
                    if not gp.exists(kit_maj + "/" + "CARTE_META_ORI"):
                        arcpy.CreateRelationshipClass_management(
                            pee_maj,
                            chemin_maj,
                            kit_maj + "/" + "CARTE_META_ORI",
                            "SIMPLE",
                            " ",
                            " ",
                            "NONE",
                            "ONE_TO_ONE",
                            "NONE",
                            "GEOCODE",
                            "GEOCODE",
                            "#")
                    else:
                        gp.AddMessage("La classe de relation CARTE_META_ORI existe deja dans la GDB %s." % (os.path.basename(kit_maj)))
                        gp.AddMessage(" ")


                if filename.startswith("DENDRO_PEE_TIGES_DHP_ORI"):
                    if not gp.exists(kit_maj + "/" + "CMP_TIGES_DHP"):
                        arcpy.CreateRelationshipClass_management(
                            pee_maj,
                            chemin_maj,
                            kit_maj + "/" + "CMP_TIGES_DHP",
                            "SIMPLE",
                            " ",
                            " ",
                            "NONE",
                            "ONE_TO_ONE",
                            "NONE",
                            "GEOCODE",
                            "GEOCODE",
                            "#")
                    else:
                        gp.AddMessage("La classe de relation CMP_TIGES_DHP existe deja dans la GDB %s." % (os.path.basename(kit_maj)))
                        gp.AddMessage(" ")


gp = arcgisscripting.create(9.3)

entree_ori = gp.GetParameterAsText(0)
entree_maj = gp.GetParameterAsText(1)

if entree_ori.endswith("gdb") and entree_maj.endswith("gdb"):
    transfert(entree_ori, entree_maj)

elif not entree_ori.endswith("gdb") and not entree_maj.endswith("gdb"):

    ##### Liste de gdb decoupees ORI
    li_gdb_ori = []
    li_gdb_ori_basename = os.listdir(entree_ori)

    for i in li_gdb_ori_basename:
        ch_ori = entree_ori + '\\' + str(i)
        li_gdb_ori.append(str(ch_ori))

    ##### Liste de gdb decoupees MAJ
    li_gdb_maj_basename = os.listdir(entree_maj)

    for j in li_gdb_maj_basename:
        split = j[:-4].split("_")
        version_maj = ""
        for t in split:
            if t in ('93', '10'):
                version_maj = t
            if len(t) >= 3:
                if t[1] in ['0','1','2','3','4','5','6','7','8','9']:
                    zone_maj = str(t)

        kit_maj = entree_maj + '\\' + str(j)

        ##### Recherche des gdb correspondantes ORI pour chaque kit MAJ
        correspond_ori = False

        for gdb in li_gdb_ori:
            split = gdb[:-4].split("_")
            version_ori = ""
            for u in split:
                if u in ('93', '10'):
                    version_ori = u

            if zone_maj in gdb and version_maj == version_ori:
                kit_ori = gdb
                correspond_ori = True


        if correspond_ori == True:
            gp.AddMessage("=============================================")
            gp.AddMessage("Sous-ensemble original: " + kit_ori)
            gp.AddMessage("Sous-ensemble a jour: " + kit_maj)
            gp.AddMessage("=============================================")
            transfert(kit_ori, kit_maj)
        else:
            gp.AddMessage("=============================================")
            gp.AddMessage("Le sous-ensemble MAJ " + kit_maj + " n'a pas de .gdb correspondante ORI.")
            gp.AddMessage("=============================================")

else:
    gp.AddError("Les parametres doivent etre soit 2 GDB uniques, soit 2 dossiers contenant des GDB.")